import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  build: {
    outDir: 'dist',
    sourcemap: false,
  },
  server: {
    host: '0.0.0.0',
    port: 3000,
    allowedHosts: [
      '3000-idc2lcq5yenm0z6b3p0i5-e4c153ef.sg2.manus.computer',
      '8328-idc2lcq5yenm0z6b3p0i5-e4c153ef.sg2.manus.computer',
    ],
  },
});
