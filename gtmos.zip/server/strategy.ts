import type { GTMContext } from '../src/types/gtm';
import { getCase } from '../src/data/cases';
import { planGTM } from '../src/lib/context';
import { invokeLLM, listLLMModels } from './_core/llm';
import { strategySchema } from './strategy-schema';

const jsonSchema = {
  type: 'json_schema',
  json_schema: {
    name: 'gtm_strategy',
    strict: true,
    schema: {
      type: 'object',
      properties: {
        market: { type: 'object', properties: { score: { type: 'number' }, confidence: { type: 'string', enum: ['High', 'Medium', 'Low'] }, summary: { type: 'string' }, evidence: { type: 'array', items: { type: 'object', properties: { dimension: { type: 'string', enum: ['market-size', 'growth', 'customer-maturity', 'competition', 'regulation', 'distribution', 'localization', 'unit-economics'] }, label: { type: 'string' }, value: { type: 'string' }, direction: { type: 'string', enum: ['positive', 'neutral', 'risk'] } }, required: ['dimension', 'label', 'value', 'direction'], additionalProperties: false } } }, required: ['score', 'confidence', 'summary', 'evidence'], additionalProperties: false },
        segment: { type: 'object', properties: { name: { type: 'string' }, companyProfile: { type: 'string' }, roles: { type: 'array', items: { type: 'string' } }, pains: { type: 'array', items: { type: 'string' } }, triggers: { type: 'array', items: { type: 'string' } }, persona: { type: 'string' } }, required: ['name', 'companyProfile', 'roles', 'pains', 'triggers', 'persona'], additionalProperties: false },
        motions: { type: 'array', items: { type: 'object', properties: { name: { type: 'string' }, share: { type: 'number' }, role: { type: 'string', enum: ['Primary', 'Secondary', 'Supporting'] }, rationale: { type: 'string' } }, required: ['name', 'share', 'role', 'rationale'], additionalProperties: false } },
        competitors: { type: 'array', items: { type: 'object', properties: { name: { type: 'string' }, customer: { type: 'string' }, product: { type: 'string' }, position: { type: 'string' }, price: { type: 'string' }, channel: { type: 'string' }, message: { type: 'string' }, strength: { type: 'string' }, weakness: { type: 'string' } }, required: ['name', 'customer', 'product', 'position', 'price', 'channel', 'message', 'strength', 'weakness'], additionalProperties: false } },
        positioning: { type: 'object', properties: { category: { type: 'string' }, target: { type: 'string' }, problem: { type: 'string' }, alternative: { type: 'string' }, differentiation: { type: 'string' }, valueProposition: { type: 'string' }, message: { type: 'string' } }, required: ['category', 'target', 'problem', 'alternative', 'differentiation', 'valueProposition', 'message'], additionalProperties: false },
        pricing: { type: 'object', properties: { model: { type: 'string' }, recommendation: { type: 'string' }, options: { type: 'array', items: { type: 'object', properties: { label: { type: 'string' }, price: { type: 'string' }, strategy: { type: 'string' }, note: { type: 'string' } }, required: ['label', 'price', 'strategy', 'note'], additionalProperties: false } } }, required: ['model', 'recommendation', 'options'], additionalProperties: false },
        channels: { type: 'array', items: { type: 'object', properties: { stage: { type: 'string', enum: ['Awareness', 'Consideration', 'Conversion', 'Retention'] }, channel: { type: 'string' }, rationale: { type: 'string' } }, required: ['stage', 'channel', 'rationale'], additionalProperties: false } },
        launch: { type: 'object', properties: { readiness: { type: 'number' }, phases: { type: 'array', items: { type: 'object', properties: { name: { type: 'string' }, duration: { type: 'string' }, focus: { type: 'string' } }, required: ['name', 'duration', 'focus'], additionalProperties: false } }, campaigns: { type: 'array', items: { type: 'string' } }, content: { type: 'array', items: { type: 'string' } }, salesPlaybook: { type: 'array', items: { type: 'string' } }, experiments: { type: 'array', items: { type: 'string' } }, kpis: { type: 'array', items: { type: 'string' } } }, required: ['readiness', 'phases', 'campaigns', 'content', 'salesPlaybook', 'experiments', 'kpis'], additionalProperties: false },
        assumptions: { type: 'array', items: { type: 'string' } },
      },
      required: ['market', 'segment', 'motions', 'competitors', 'positioning', 'pricing', 'channels', 'launch', 'assumptions'],
      additionalProperties: false,
    },
  },
};

function chooseModel(ids: string[]): string {
  const preferences = ['gpt-5-mini', 'gpt-5', 'gpt-5.5', 'gpt-5-nano'];
  const found = preferences.find((id) => ids.includes(id));
  if (!found) throw new Error('No supported strategy model is currently available.');
  return found;
}

export async function generateStrategy(context: GTMContext, language: 'en' | 'zh' = 'en') {
  const caseData = getCase(context.caseId);
  const { motions, modules, profile } = planGTM(context);
  const models = await listLLMModels();
  const model = chooseModel(models.map((entry) => entry.id));
  const languageInstruction = language === 'zh' ? 'Write all user-facing strategy strings in clear, concise Simplified Chinese. Keep product and proper names as supplied.' : 'Write compact, actionable English for a product leadership team.';
  const system = `You are GTM OS, a pragmatic go-to-market strategist. Return only the requested JSON object. Treat supplied market/competitor facts as hypotheses unless explicitly sourced. Never invent current market statistics; label estimates as assumptions. ${languageInstruction} The user needs a differentiated plan, not generic advice.`;
  const user = JSON.stringify({
    task: 'Create a concise but complete GTM strategy for the supplied launch context.',
    context,
    adaptiveProfile: profile,
    selectedMotionHypotheses: motions,
    analysisWeights: modules,
    relatedCasePattern: { product: caseData.product, market: caseData.market, category: caseData.strategy.positioning.category },
    outputRules: ['Keep evidence illustrative unless a verified source was supplied; never invent current market statistics.', 'Include exactly one signal for each of the eight required market dimensions.', 'Make the target, pain, wedge and entry motion specific.', 'Provide exactly 3 concise competitors with all required customer, product, position, price, channel, message, strength and weakness fields.', 'Provide 2–4 motions with exactly one Primary and shares totaling 100.', 'Choose only a relevant pricing architecture: subscription, usage/seat-based, freemium, hardware margin, marketplace take rate or enterprise contract.', 'Provide exactly 3 pricing options, exactly 4 channel recommendations (one for each funnel stage), exactly 3 launch phases, 2 concise campaigns, 2 content assets, 2 sales playbook actions, 2 experiments, 4 measurable KPIs and 3 concise assumptions.', 'Keep every text field concise; use short phrases or one brief sentence rather than paragraphs.', 'Keep market score and launch readiness between 0 and 100 and confidence calibrated.', 'Return a complete JSON object matching every required field and enum in the schema.'],
  });
  const response = await invokeLLM({
    model,
    messages: [{ role: 'system', content: system }, { role: 'user', content: user }],
    response_format: jsonSchema,
    max_completion_tokens: 10000,
  });
  const choice = response.choices?.[0];
  const content = choice?.message?.content;
  if (typeof content !== 'string' || !content.trim()) throw new Error('The AI returned an empty strategy. Keep the brief and retry.');
  let decoded: unknown;
  try {
    const clean = content.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '').trim();
    const first = clean.indexOf('{');
    const last = clean.lastIndexOf('}');
    if (first < 0 || last < first) throw new Error('Missing JSON object');
    decoded = JSON.parse(clean.slice(first, last + 1));
  } catch (cause) {
    console.error('[strategy] invalid structured output', { model, finishReason: choice?.finish_reason, characters: content.length, tail: content.slice(-180) });
    if (choice?.finish_reason === 'length') throw new Error('The AI response reached its output limit. Retry the same brief.');
    throw new Error('The AI response was not valid JSON. Keep the brief and retry.');
  }
  const result = strategySchema.safeParse(decoded);
  if (!result.success) {
    console.error('[strategy] schema validation failed', result.error.issues.map(({ code, path, message }) => ({ code, path: path.join('.'), message })));
    throw new Error('The AI response did not match the strategy format. Keep the brief and use the case preview or retry.');
  }
  const finalMotions = motions.map((planned) => {
    const generated = result.data.motions.find((candidate) => candidate.name.trim().toLowerCase() === planned.name.trim().toLowerCase());
    return { ...planned, rationale: generated?.rationale.trim() || planned.rationale };
  });
  return { strategy: { ...result.data, motions: finalMotions }, model, source: 'manus-ai' as const, planner: { profile, motions, modules } };
}
