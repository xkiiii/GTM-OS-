interface ModelInfo {
  id: string;
  pricing?: Record<string, unknown>;
  capabilities?: Record<string, unknown>;
}

interface ChatMessage {
  role: 'system' | 'user';
  content: string;
}

function apiConfig() {
  const baseUrl = process.env.BUILT_IN_FORGE_API_URL ?? process.env.MANUS_API_URL;
  const apiKey = process.env.BUILT_IN_FORGE_API_KEY ?? process.env.MANUS_API_KEY;
  if (!baseUrl || !apiKey) throw new Error('Managed AI service credentials are not available in this runtime.');
  return { baseUrl: baseUrl.replace(/\/+$/, ''), apiKey };
}

async function readJson<T>(url: string, init: RequestInit): Promise<T> {
  const response = await fetch(url, init);
  const payload = await response.json().catch(() => ({})) as T & { error?: { message?: string } };
  if (!response.ok || (payload as { error?: unknown }).error) {
    const message = (payload as { error?: { message?: string } }).error?.message;
    throw new Error(message || `Managed AI request failed (${response.status}).`);
  }
  return payload;
}

export async function listLLMModels(): Promise<ModelInfo[]> {
  const { baseUrl, apiKey } = apiConfig();
  const response = await readJson<{ data?: ModelInfo[] }>(`${baseUrl}/v1/models`, {
    headers: { Authorization: `Bearer ${apiKey}` },
    signal: AbortSignal.timeout(12000),
  });
  return response.data ?? [];
}

export async function invokeLLM(input: {
  model: string;
  messages: ChatMessage[];
  response_format: Record<string, unknown>;
  max_completion_tokens?: number;
  reasoning?: { effort: 'low' | 'medium' | 'high' };
}): Promise<{ choices?: { finish_reason?: string | null; message?: { content?: string | null } }[] }> {
  const { baseUrl, apiKey } = apiConfig();
  return readJson(`${baseUrl}/v1/chat/completions`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(input),
    signal: AbortSignal.timeout(75000),
  });
}
