import { z } from 'zod';

const MarketDimension = z.enum(['market-size', 'growth', 'customer-maturity', 'competition', 'regulation', 'distribution', 'localization', 'unit-economics']);
const Evidence = z.object({ dimension: MarketDimension, label: z.string().min(1), value: z.string().min(1), direction: z.enum(['positive', 'neutral', 'risk']) });
const MarketEvidenceSet = z.array(Evidence).length(8)
  .refine((items) => new Set(items.map((item) => item.dimension)).size === 8, { message: 'Market evidence must cover all eight distinct dimensions.' });
const Motion = z.object({ name: z.string().min(1), share: z.number().min(0).max(100), role: z.enum(['Primary', 'Secondary', 'Supporting']), rationale: z.string().min(1) });
const Competitor = z.object({ name: z.string().min(1), customer: z.string().min(1), product: z.string().min(1), position: z.string().min(1), price: z.string().min(1), channel: z.string().min(1), message: z.string().min(1), strength: z.string().min(1), weakness: z.string().min(1) });
const PriceOption = z.object({ label: z.string().min(1), price: z.string().min(1), strategy: z.string().min(1), note: z.string().min(1) });
const Channel = z.object({ stage: z.enum(['Awareness', 'Consideration', 'Conversion', 'Retention']), channel: z.string().min(1), rationale: z.string().min(1) });
const ExecutionActions = z.array(z.string().min(5)).min(2).max(4);
const MotionPlan = z.array(Motion).min(2).max(4)
  .refine((motions) => Math.abs(motions.reduce((total, motion) => total + motion.share, 0) - 100) <= 0.5, { message: 'Motion allocation must total 100%.' })
  .refine((motions) => motions.filter((motion) => motion.role === 'Primary').length === 1, { message: 'Exactly one motion must be Primary.' });
const FunnelPlan = z.array(Channel).min(4).max(8)
  .refine((channels) => ['Awareness', 'Consideration', 'Conversion', 'Retention'].every((stage) => channels.some((channel) => channel.stage === stage)), { message: 'The channel plan must cover every funnel stage.' });

export const strategySchema = z.object({
  market: z.object({ score: z.number().min(0).max(100), confidence: z.enum(['High', 'Medium', 'Low']), summary: z.string().min(1), evidence: MarketEvidenceSet }),
  segment: z.object({ name: z.string().min(1), companyProfile: z.string().min(1), roles: z.array(z.string()).min(1), pains: z.array(z.string()).min(2), triggers: z.array(z.string()).min(1), persona: z.string().min(1) }),
  motions: MotionPlan,
  competitors: z.array(Competitor).min(2).max(4),
  positioning: z.object({ category: z.string().min(1), target: z.string().min(1), problem: z.string().min(1), alternative: z.string().min(1), differentiation: z.string().min(1), valueProposition: z.string().min(1), message: z.string().min(1) }),
  pricing: z.object({ model: z.string().min(1), recommendation: z.string().min(1), options: z.array(PriceOption).min(3).max(3) }),
  channels: FunnelPlan,
  launch: z.object({ readiness: z.number().min(0).max(100), phases: z.array(z.object({ name: z.string().min(1), duration: z.string().min(1), focus: z.string().min(1) })).min(3).max(4), campaigns: ExecutionActions, content: ExecutionActions, salesPlaybook: ExecutionActions, experiments: ExecutionActions, kpis: z.array(z.string()).min(3).max(6) }),
  assumptions: z.array(z.string()).min(1).max(8),
});

export type ValidatedStrategy = z.infer<typeof strategySchema>;
