import express from 'express';
import { createServer as createHttpServer } from 'node:http';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { z } from 'zod';
import { generateStrategy } from './strategy';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const port = Number(process.env.PORT || 3000);
const app = express();
const httpServer = createHttpServer(app);
app.set('trust proxy', 1);
const rateLimitWindowMs = 10 * 60 * 1000;
const rateLimitMax = 8;
const strategyAttempts = new Map<string, { count: number; resetAt: number }>();
const contextSchema = z.object({
  product: z.string().trim().min(2).max(160),
  market: z.string().trim().min(2).max(100),
  businessModel: z.enum(['Subscription', 'Usage based', 'One-off', 'Marketplace']),
  customerType: z.enum(['B2B', 'B2C', 'B2B2C']),
  stage: z.enum(['0 → 1', 'PMF', 'Growth', 'Expansion']),
  objective: z.enum(['Market entry', 'Launch', 'Growth', 'Repositioning']),
  acv: z.number().positive().max(100000000),
  budget: z.number().positive().max(100000000),
  target: z.string().trim().min(2).max(240),
  motion: z.string().trim().min(2).max(100),
  caseId: z.enum(['meeting', 'camera', 'security']),
});

app.disable('x-powered-by');
app.use(express.json({ limit: '16kb' }));
app.get('/api/health', (_request, response) => response.json({ ok: true }));
app.post('/api/strategy', async (request, response) => {
  const parsed = contextSchema.safeParse(request.body?.context);
  if (!parsed.success) {
    response.status(400).json({ error: 'Please complete the launch brief with valid values.', code: 'invalid_context' });
    return;
  }
  const now = Date.now();
  const clientKey = request.ip || 'unknown';
  const bucket = strategyAttempts.get(clientKey);
  if (strategyAttempts.size > 1000) {
    for (const [key, entry] of strategyAttempts) if (entry.resetAt <= now) strategyAttempts.delete(key);
  }
  if (bucket && bucket.resetAt > now && bucket.count >= rateLimitMax) {
    response.setHeader('Retry-After', String(Math.ceil((bucket.resetAt - now) / 1000)));
    response.status(429).json({ error: 'Too many strategy requests. Wait a few minutes and retry.', code: 'rate_limited' });
    return;
  }
  strategyAttempts.set(clientKey, !bucket || bucket.resetAt <= now ? { count: 1, resetAt: now + rateLimitWindowMs } : { ...bucket, count: bucket.count + 1 });
  response.setHeader('Cache-Control', 'no-store');
  try {
    const language = request.body?.language === 'zh' ? 'zh' : 'en';
    const result = await generateStrategy(parsed.data, language);
    response.json(result);
  } catch (error) {
    console.error('[strategy] generation failed', error instanceof Error ? error.message : error);
    response.status(502).json({ error: 'Strategy generation could not be completed. Your brief is saved; please retry.', code: 'strategy_unavailable' });
  }
});

if (process.env.NODE_ENV === 'production') {
  app.use(express.static(resolve(root, 'dist'), { index: false, maxAge: '1h' }));
  app.use((_request, response) => response.sendFile(resolve(root, 'dist', 'index.html')));
} else {
  const { createServer: createViteServer } = await import('vite');
  const vite = await createViteServer({
    root,
    server: { middlewareMode: true, hmr: { server: httpServer } },
    appType: 'spa',
  });
  app.use(vite.middlewares);
}

httpServer.listen(port, '0.0.0.0', () => {
  console.log(`GTM OS listening on 0.0.0.0:${port}`);
});
