# GTM OS — AI Go-To-Market Decision Agent

An AI-native GTM decision workspace for turning product, market and growth context into a coherent go-to-market plan—and making the trade-offs visible in a live scenario simulator.

## Product loop

**Business context → Market → Segment / ICP → Competition → Positioning → Pricing → Channel → Motion → Launch → Measurement → Iteration**

The same GTM core is demonstrated across three deliberately different launch contexts:

- **AI meeting assistant → United States:** PLG, sales-assisted adoption and RevOps workflows.
- **Action camera → Germany:** retail, creator-led discovery and consumer distribution.
- **Cybersecurity SaaS → Japan:** enterprise sales, partner trust and paid proof-of-value.

The Context Engine captures product, market, business model, customer type, stage, objective, ACV / unit value, target segment and sales motion. `src/lib/context.ts` derives motion hypotheses and analysis weights from those inputs rather than running the same playbook for every case.

## What is interactive

- Switch between the three portfolio cases.
- Edit context and request a structured strategy from the server-side managed Manus AI service.
- Explore a clear strategy across opportunity signals, target segment, motion, competitive alternatives, positioning, price, channel and launch plan.
- Compare Lean / Balanced / Premium scenarios or adjust price, target, market, budget and motion. The simulator recalculates directional CAC, conversion, sales cycle, gross margin and reach.
- Switch between English and Simplified Chinese.

## Run locally

```bash
pnpm install
pnpm dev
```

Preview defaults to `http://localhost:3000`. The production frontend can be built with `pnpm build`; `pnpm start` serves `dist/` and the same-origin strategy API.

## Architecture

- **Frontend:** React 18, TypeScript, Vite, Lucide icons.
- **Server:** Express, same-origin `/api/strategy`, request validation with Zod.
- **AI:** managed Manus LLM access through the server-only helper in `server/_core/llm.ts`; provider credentials are never exposed to browser code.
- **Route declaration:** `public/manus-routes.json`.

## Assumptions and evidence boundary

The sample market scores, competitor descriptions, competitor-price labels, launch readiness and simulator outputs are **illustrative planning hypotheses**, not sourced market research or a forecast. The AI prompt asks the model not to invent current statistics; validate category facts, pricing, competitor claims and simulator coefficients with customer interviews and observed cohort data before using them for a real launch decision.

## Quality checks

```bash
pnpm check
pnpm build
```
