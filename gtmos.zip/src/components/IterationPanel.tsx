import { useEffect, useState, type FormEvent } from 'react';
import { Activity, ArrowRight, Check, RotateCcw } from 'lucide-react';
import type { GTMStrategy, Language } from '../types/gtm';

interface Props { caseId: string; strategy: GTMStrategy; language: Language; }
interface IterationRecord { experiment: string; metric: string; result: string; nextDecision: string; recordedAt: string; }
const HISTORY_LIMIT = 12;

const copy = {
  en: {
    eyebrow: '09 / LEARNING LOOP', title: 'Measure what changed. Choose what happens next.',
    intro: `Turn a launch signal into a documented decision. The latest ${HISTORY_LIMIT} records stay in this browser and are separated by case.`,
    experiment: 'Experiment / cohort', metric: 'KPI being measured', result: 'Observed result', next: 'Next decision',
    experimentHint: 'e.g. Guided onboarding for new teams', resultHint: 'e.g. 41% activation vs. 50% target', nextHint: 'What will you scale, change or stop based on this result?',
    save: 'Record iteration', latest: 'RECENT ITERATIONS', empty: 'No result recorded yet. Add an experiment and its observed outcome to start the loop.',
    recorded: 'Recorded', remove: 'Clear history', storageError: 'Browser storage is unavailable or full. Your draft is preserved; copy it and try again.',
  },
  zh: {
    eyebrow: '09 / 学习闭环', title: '测量变化，并决定下一步。',
    intro: `把上市信号转成可追溯的决策。最近 ${HISTORY_LIMIT} 条记录保存在当前浏览器，并按案例分别存储。`,
    experiment: '实验 / 客群', metric: '测量指标', result: '实际结果', next: '下一步决策',
    experimentHint: '例如：为新团队提供引导式 onboarding', resultHint: '例如：激活率 41%，目标 50%', nextHint: '基于这个结果，你会扩大、调整还是停止什么？',
    save: '记录本轮迭代', latest: '最近的迭代记录', empty: '还没有记录结果。添加一个实验及其观测结果，启动学习闭环。',
    recorded: '记录于', remove: '清除全部记录', storageError: '浏览器存储不可用或空间不足。表单内容仍保留，请先复制后重试。',
  },
};

function isIterationRecord(value: unknown): value is IterationRecord {
  if (!value || typeof value !== 'object') return false;
  const record = value as Partial<IterationRecord>;
  return typeof record.experiment === 'string' && typeof record.metric === 'string' && typeof record.result === 'string' && typeof record.nextDecision === 'string' && typeof record.recordedAt === 'string';
}

function loadRecords(key: string): IterationRecord[] {
  try {
    const parsed: unknown = JSON.parse(localStorage.getItem(key) ?? 'null');
    const records = Array.isArray(parsed) ? parsed.filter(isIterationRecord) : isIterationRecord(parsed) ? [parsed] : [];
    return records.slice(0, HISTORY_LIMIT);
  } catch { return []; }
}

function recordedAt(value: string, language: Language) {
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) return value;
  return new Intl.DateTimeFormat(language === 'zh' ? 'zh-CN' : 'en', { dateStyle: 'medium', timeStyle: 'short' }).format(date);
}

export default function IterationPanel({ caseId, strategy, language }: Props) {
  const t = copy[language];
  const storageKey = `gtm-os-iteration:${caseId}`;
  const [records, setRecords] = useState<IterationRecord[]>(() => loadRecords(storageKey));
  const [experiment, setExperiment] = useState('');
  const [metric, setMetric] = useState(strategy.launch.kpis[0] ?? 'Activation rate');
  const [result, setResult] = useState('');
  const [nextDecision, setNextDecision] = useState('');
  const [storageError, setStorageError] = useState('');

  useEffect(() => {
    setRecords(loadRecords(storageKey));
    setExperiment('');
    setMetric(strategy.launch.kpis[0] ?? 'Activation rate');
    setResult('');
    setNextDecision('');
    setStorageError('');
  }, [caseId]);

  useEffect(() => {
    if (!strategy.launch.kpis.includes(metric) && strategy.launch.kpis[0]) setMetric(strategy.launch.kpis[0]);
  }, [strategy.launch.kpis, metric]);

  const save = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const record: IterationRecord = { experiment: experiment.trim(), metric, result: result.trim(), nextDecision: nextDecision.trim(), recordedAt: new Date().toISOString() };
    const nextRecords = [record, ...records].slice(0, HISTORY_LIMIT);
    try {
      localStorage.setItem(storageKey, JSON.stringify(nextRecords));
    } catch {
      setStorageError(t.storageError);
      return;
    }
    setRecords(nextRecords);
    setStorageError('');
    setExperiment('');
    setResult('');
    setNextDecision('');
  };

  const clear = () => {
    try {
      localStorage.removeItem(storageKey);
    } catch {
      setStorageError(t.storageError);
      return;
    }
    setRecords([]);
    setStorageError('');
  };

  return <section className="panel iteration-panel" id="measurement" aria-labelledby="iteration-title">
    <div className="iteration-panel-head">
      <div><div className="eyebrow">{t.eyebrow}</div><h2 id="iteration-title">{t.title}</h2><p>{t.intro}</p></div>
      <span className="iteration-icon"><Activity size={17} /></span>
    </div>
    <div className="iteration-workspace" id="iteration">
      <form className="iteration-form" onSubmit={save}>
        <label className="iteration-field"><span>{t.experiment}</span><input required maxLength={120} value={experiment} onChange={(event) => setExperiment(event.target.value)} placeholder={t.experimentHint} /></label>
        <label className="iteration-field"><span>{t.metric}</span><select value={metric} onChange={(event) => setMetric(event.target.value)}>{strategy.launch.kpis.map((kpi) => <option key={kpi}>{kpi}</option>)}</select></label>
        <label className="iteration-field"><span>{t.result}</span><input required maxLength={160} value={result} onChange={(event) => setResult(event.target.value)} placeholder={t.resultHint} /></label>
        <label className="iteration-field"><span>{t.next}</span><textarea required maxLength={280} rows={2} value={nextDecision} onChange={(event) => setNextDecision(event.target.value)} placeholder={t.nextHint} /></label>
        <button className="iteration-submit" type="submit"><Check size={14} />{t.save}<ArrowRight size={14} /></button>
      </form>
      {storageError && <p className="iteration-storage-error" role="alert">{storageError}</p>}
      <div className="iteration-latest" aria-live="polite">
        <div className="iteration-history-heading"><div className="mini-heading">{t.latest}<span className="iteration-count">{records.length}</span></div>{records.length > 0 && <button type="button" onClick={clear}><RotateCcw size={11} />{t.remove}</button>}</div>
        {records.length > 0 ? <div className="iteration-history-list">{records.map((record) => <article className="iteration-record" key={`${record.recordedAt}-${record.experiment}`}>
          <div className="iteration-record-title"><span className="record-dot" />{record.experiment}</div>
          <div className="iteration-record-metric"><span>{record.metric}</span><strong>{record.result}</strong></div>
          <p className="iteration-next"><b>{t.next}</b>{record.nextDecision}</p>
          <div className="iteration-record-footer"><span>{t.recorded} · {recordedAt(record.recordedAt, language)}</span></div>
        </article>)}</div> : <p className="iteration-empty">{t.empty}</p>}
      </div>
    </div>
  </section>;
}
