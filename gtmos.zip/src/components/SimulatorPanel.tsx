import { useEffect, useState } from 'react';
import { ArrowDownRight, ArrowUpRight, Equal, SlidersHorizontal, Sparkles } from 'lucide-react';
import { calculateMetrics, defaultSimulatorInputs, deltaLabel } from '../lib/simulator';
import { formatMarketMoney } from '../lib/currency';
import type { DemoCase, Language, SimulatorInputs } from '../types/gtm';

interface Props {
  item: DemoCase;
  baselineItem: DemoCase;
  inputs: SimulatorInputs;
  onChange: (next: SimulatorInputs) => void;
  motions: string[];
  language: Language;
  t: Record<string, string>;
}

const text = {
  en: { price: 'Price / contract', target: 'Target segment', market: 'Market', budget: 'Launch budget', motion: 'GTM motion', lean: 'Lean', balanced: 'Balanced', premium: 'Premium', model: 'Illustrative model · not a forecast', baseline: 'vs. baseline', assumption: 'Directional LTV assumes 24-month self-serve, 30-month mid-market or 36-month enterprise life; price-to-conversion elasticity is −0.16. Calibrate with observed cohort data.', edit: 'Adjust the bet', saved: 'Decision changed' },
  zh: { price: '价格 / 合同额', target: '目标客群', market: '目标市场', budget: '上市预算', motion: 'GTM 路径', lean: '精益', balanced: '平衡', premium: '高端', model: '示意模型 · 非预测', baseline: '对比基线', assumption: '示意 LTV 假设：自助 24 个月、中端 30 个月、企业 36 个月生命周期；价格—转化弹性按 −0.16 估算。请用实际队列数据校准。', edit: '调整决策变量', saved: '决策已改变' },
};

export default function SimulatorPanel({ item, baselineItem, inputs, onChange, motions, language, t }: Props) {
  const copy = text[language];
  const [scenario, setScenario] = useState('Balanced');
  useEffect(() => setScenario('Balanced'), [baselineItem.id]);
  const baselineInputs = defaultSimulatorInputs(baselineItem);
  const baseline = calculateMetrics(baselineItem, baselineInputs);
  const current = calculateMetrics(item, inputs);

  const applyPreset = (preset: string) => {
    setScenario(preset);
    const base = defaultSimulatorInputs(baselineItem);
    const next = preset === 'Lean'
      ? { ...base, price: Math.round(base.price * 0.78), budget: Math.round(base.budget * 0.72) }
      : preset === 'Premium'
        ? { ...base, price: Math.round(base.price * 1.32), budget: Math.round(base.budget * 1.25) }
        : base;
    onChange(next);
  };

  const update = (partial: Partial<SimulatorInputs>) => {
    setScenario('Custom');
    onChange({ ...inputs, ...partial });
  };

  const metrics = [
    { label: t.estimatedCac, value: formatMarketMoney(current.cac, inputs.market), delta: deltaLabel(current.cac, baseline.cac, true), icon: ArrowDownRight },
    { label: t.ltv, value: formatMarketMoney(current.ltv, inputs.market), delta: deltaLabel(current.ltv, baseline.ltv), icon: ArrowUpRight },
    { label: t.ltvCac, value: `${current.ltvCac}×`, delta: deltaLabel(current.ltvCac, baseline.ltvCac), icon: ArrowUpRight },
    { label: t.conversion, value: `${current.conversion}%`, delta: deltaLabel(current.conversion, baseline.conversion), icon: ArrowUpRight },
    { label: t.cycle, value: `${current.salesCycle} ${t.days}`, delta: deltaLabel(current.salesCycle, baseline.salesCycle, true), icon: ArrowDownRight },
    { label: t.margin, value: `${current.grossMargin}%`, delta: deltaLabel(current.grossMargin, baseline.grossMargin), icon: ArrowUpRight },
    { label: t.reach, value: `${current.reach}%`, delta: deltaLabel(current.reach, baseline.reach), icon: ArrowUpRight },
  ];
  const priceMin = item.model === 'One-off' ? 100 : item.acv > 10000 ? 10000 : 10;
  const priceMax = item.model === 'One-off' ? 900 : item.acv > 10000 ? 150000 : 99;
  const targetOptions = item.customerType === 'B2B'
    ? ['SMB · 10–200 employees', 'Mid-market · 200–1,000 employees', 'Enterprise · 1,000+ employees']
    : ['Outdoor enthusiasts', 'Adventure creators', 'Specialty retail', 'Premium consumers'];
  if (!targetOptions.includes(inputs.target)) targetOptions.unshift(inputs.target);
  const motionOptions = Array.from(new Set([inputs.motion, ...motions]));

  return (
    <section className="simulator-card" id="simulator" aria-label={t.simulator}>
      <div className="simulator-head">
        <div className="eyebrow"><span className="live-dot" />{language === 'zh' ? '实时情景' : 'LIVE SCENARIO'}</div>
        <div className="simulator-title-row"><h2>{t.simulator}</h2><span className="icon-chip lime"><SlidersHorizontal size={15} /></span></div>
        <p>{language === 'zh' ? '调整一个决策，立即看影响。' : 'Change one decision. See the trade-off.'}</p>
      </div>
      <div className="scenario-switch" role="group" aria-label={t.compare}>
        {['Lean', 'Balanced', 'Premium'].map((preset) => <button key={preset} className={scenario === preset ? 'scenario-btn active' : 'scenario-btn'} onClick={() => applyPreset(preset)}>{copy[preset.toLowerCase() as 'lean' | 'balanced' | 'premium']}</button>)}
      </div>

      <div className="sim-controls">
        <label className="control-label" htmlFor="sim-price"><span>{copy.price}</span><strong>{formatMarketMoney(inputs.price, inputs.market)}</strong></label>
        <input id="sim-price" className="range-input" type="range" min={priceMin} max={priceMax} step={item.acv > 10000 ? 1000 : 1} value={inputs.price} onChange={(event) => update({ price: Number(event.target.value) })} />
        <label className="control-label" htmlFor="sim-target"><span>{copy.target}</span></label>
        <select id="sim-target" value={inputs.target} onChange={(event) => update({ target: event.target.value })}>{targetOptions.map((option) => <option key={option}>{option}</option>)}</select>
        <label className="control-label" htmlFor="sim-market"><span>{copy.market}</span></label>
        <input id="sim-market" className="sim-market-input" list="sim-market-options" maxLength={100} value={inputs.market} onChange={(event) => update({ market: event.target.value })} placeholder={language === 'zh' ? '输入任意市场' : 'Type any market'} />
        <datalist id="sim-market-options"><option value="United States" /><option value="Germany" /><option value="Japan" /><option value="United Kingdom" /><option value="Singapore" /><option value="Southeast Asia" /></datalist>
        <label className="control-label" htmlFor="sim-budget"><span>{copy.budget}</span><strong>{formatMarketMoney(inputs.budget, inputs.market)}</strong></label>
        <input id="sim-budget" className="range-input" type="range" min="10000" max="1000000" step="10000" value={inputs.budget} onChange={(event) => update({ budget: Number(event.target.value) })} />
        <label className="control-label" htmlFor="sim-motion"><span>{copy.motion}</span></label>
        <select id="sim-motion" value={inputs.motion} onChange={(event) => update({ motion: event.target.value })}>{motionOptions.map((option) => <option key={option}>{option}</option>)}</select>
      </div>

      <div className="sim-results-head"><span>{language === 'zh' ? '结果变化' : 'OUTCOME DELTA'}</span><span className="baseline-key"><i />{t.baseline}</span></div>
      <div className="metrics-stack">
        {metrics.map(({ label, value, delta, icon: Icon }) => {
          const DeltaIcon = delta.tone === 'good' ? Icon : delta.tone === 'bad' ? ArrowDownRight : Equal;
          return <div className="metric-row" key={label}>
            <span className="metric-label">{label}</span>
            <div className="metric-value-line"><strong>{value}</strong><span className={`delta ${delta.tone}`}><DeltaIcon size={12} />{delta.text}</span></div>
          </div>;
        })}
      </div>
      <div className="sim-assumption"><Sparkles size={14} /><span>{copy.assumption}</span></div>
      <div className="sim-stamp"><span className="stamp-dot" />{copy.model}<span className="scenario-status">{scenario === 'Custom' ? copy.saved : copy[scenario.toLowerCase() as 'lean' | 'balanced' | 'premium']}</span></div>
    </section>
  );
}
