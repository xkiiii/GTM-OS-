import { ArrowRight, Check, ChevronRight, Crosshair, ShieldCheck, TrendingUp } from 'lucide-react';
import type { GTMStrategy, Language, MarketDimension, MotionPlan } from '../types/gtm';
import type { WorkflowModule } from '../lib/context';

interface Props { strategy: GTMStrategy; t: Record<string, string>; language: Language; currency: string; }

const marketDimensionLabels: Record<MarketDimension, { en: string; zh: string }> = {
  'market-size': { en: 'Market size', zh: '市场规模' },
  growth: { en: 'Market growth', zh: '市场增长' },
  'customer-maturity': { en: 'Customer maturity', zh: '客户成熟度' },
  competition: { en: 'Competition', zh: '竞争强度' },
  regulation: { en: 'Regulation', zh: '监管环境' },
  distribution: { en: 'Distribution', zh: '分销可达性' },
  localization: { en: 'Localization', zh: '本地化要求' },
  'unit-economics': { en: 'Unit economics', zh: '单位经济' },
};

export function MarketCard({ strategy, t, language }: Props) {
  const market = strategy.market;
  return <section className="panel market-card" id="market">
    <div className="panel-top"><div><div className="eyebrow">01 / OPPORTUNITY</div><h2>{t.market}</h2></div><span className={`confidence-tag ${market.confidence.toLowerCase()}`}>{t.confidence} · {language === 'zh' ? (market.confidence === 'High' ? '高' : market.confidence === 'Medium' ? '中' : '低') : market.confidence}</span></div>
    <div className="market-score-row"><div className="score-ring" style={{ '--score': `${market.score}%` } as React.CSSProperties}><div><strong>{market.score}</strong><span>/ 100</span></div></div><div className="market-summary"><div className="score-caption">{language === 'zh' ? '机会吸引力' : 'MARKET ATTRACTIVENESS'}</div><p>{market.summary}</p><div className="source-note"><span className="source-dot" />{language === 'zh' ? '示意估算 · 需外部验证' : 'Illustrative score · validate with research'}</div></div></div>
    <div className="evidence-list">{market.evidence.map((evidence) => <div className="evidence-line" key={evidence.dimension}><span className={`evidence-dot ${evidence.direction}`} /><span>{language === 'zh' ? marketDimensionLabels[evidence.dimension].zh : marketDimensionLabels[evidence.dimension].en}</span><strong>{evidence.value}</strong></div>)}</div>
    <details className="assumption-disclosure"><summary>{language === 'zh' ? '需要验证的假设' : 'ASSUMPTIONS TO VALIDATE'}<span>{strategy.assumptions.length}</span></summary><ul>{strategy.assumptions.map((assumption, index) => <li key={`${index}-${assumption.slice(0, 24)}`}>{assumption}</li>)}</ul></details>
  </section>;
}

export function SegmentCard({ strategy, t, language }: Props) {
  const segment = strategy.segment;
  return <section className="panel segment-card" id="segment">
    <div className="panel-top"><div><div className="eyebrow">02 / WHO</div><h2>{t.target}</h2></div><span className="icon-chip"><Crosshair size={16} /></span></div>
    <h3 className="segment-title">{segment.name}</h3><p className="segment-profile">{segment.companyProfile}</p>
    <div className="icp-block" id="icp" tabIndex={-1}>
      <div className="icp-block-heading"><span className="eyebrow">03 / ICP DEFINITION</span><span>{language === 'zh' ? '理想客户画像' : 'IDEAL CUSTOMER PROFILE'}</span></div>
      <div className="mini-heading">{language === 'zh' ? '关键角色' : 'BUYING ROLES'}</div><div className="role-pills">{segment.roles.map((role) => <span key={role}>{role}</span>)}</div>
      <div className="pain-grid"><div><div className="mini-heading">{language === 'zh' ? '核心痛点' : 'PAIN SIGNALS'}</div>{segment.pains.slice(0, 3).map((pain) => <p className="bullet-line" key={pain}><span>↗</span>{pain}</p>)}</div><div><div className="mini-heading">{language === 'zh' ? '购买触发' : 'TRIGGERS'}</div>{segment.triggers.slice(0, 3).map((trigger) => <p className="bullet-line" key={trigger}><span>·</span>{trigger}</p>)}</div></div>
      <div className="persona-note"><span className="persona-mark">“</span><p>{segment.persona}</p></div>
    </div>
  </section>;
}

export function MotionCard({ motions, modules, t, language }: { motions: MotionPlan[]; modules: WorkflowModule[]; t: Record<string, string>; language: Language }) {
  return <section className="panel motion-card" id="motion">
    <div className="panel-top"><div><div className="eyebrow">03 / HOW</div><h2>{t.motion}</h2></div><span className="motion-total">{motions.length} {language === 'zh' ? '路径' : 'MOTIONS'}</span></div>
    <div className="motion-list">{motions.map((motion, index) => <div className="motion-item" key={motion.name}>
      <div className="motion-title"><div className={`motion-index m${index + 1}`}>0{index + 1}</div><div className="motion-copy"><strong>{motion.name}</strong><span>{motion.role === 'Primary' ? (language === 'zh' ? '主要路径' : 'PRIMARY') : motion.role === 'Secondary' ? (language === 'zh' ? '次要路径' : 'SECONDARY') : (language === 'zh' ? '支持路径' : 'SUPPORTING')}</span></div><b>{motion.share}%</b></div>
      <div className="motion-bar"><i style={{ width: `${motion.share}%` }} /></div><p>{motion.rationale}</p>
    </div>)}</div>
    <div className="module-weight-list"><div className="mini-heading">{language === 'zh' ? '动态规划权重' : 'ADAPTIVE PLAN WEIGHTS'}</div>{modules.map((module) => <div className="weight-row" key={module.id}><span>{module.title}</span><div className="weight-track"><i style={{ width: `${module.weight}%` }} /></div><b>{module.weight}</b></div>)}</div>
  </section>;
}

export function PositioningCard({ strategy, t, language }: Props) {
  const item = strategy.positioning;
  const labels = language === 'zh' ? ['品类', '目标', '问题', '替代方案', '差异化'] : ['CATEGORY', 'FOR', 'PROBLEM', 'ALTERNATIVE', 'DIFFERENTIATION'];
  const values = [item.category, item.target, item.problem, item.alternative, item.differentiation];
  return <section className="panel positioning-card" id="positioning">
    <div className="panel-top"><div><div className="eyebrow">04 / WHAT</div><h2>{t.positioning}</h2></div><span className="icon-chip lime"><TrendingUp size={16} /></span></div>
    <div className="positioning-flow">{values.map((value, index) => <div className="position-step" key={labels[index]}><span>{labels[index]}</span><p>{value}</p>{index < values.length - 1 && <ChevronRight size={14} className="flow-chevron" />}</div>)}</div>
    <div className="value-proposition"><div className="eyebrow">VALUE PROPOSITION</div><h3>{item.valueProposition}</h3><div className="message-row"><span>{language === 'zh' ? '核心信息' : 'MESSAGE'}</span><p>{item.message}</p></div></div>
  </section>;
}

export function PricingCard({ strategy, t, language }: Props) {
  const pricing = strategy.pricing;
  return <section className="panel pricing-card" id="pricing">
    <div className="panel-top"><div><div className="eyebrow">05 / VALUE CAPTURE</div><h2>{t.pricing}</h2></div><span className="icon-chip"><ShieldCheck size={16} /></span></div>
    <p className="pricing-model">{pricing.model}</p><div className="price-recommendation"><div><span>{language === 'zh' ? '建议起点' : 'RECOMMENDED START'}</span><strong>{pricing.recommendation}</strong></div><span className="recommended-pill"><Check size={12} />{language === 'zh' ? '平衡' : 'BALANCED'}</span></div>
    <div className="price-options">{pricing.options.map((option, index) => <div className={`price-option ${index === 1 ? 'featured' : ''}`} key={option.label}><div className="price-option-top"><div><span>{option.label}</span><strong>{option.price}</strong></div><span className="option-strategy">{option.strategy}</span></div><p>{option.note}</p></div>)}</div>
    <div className="pricing-note">{language === 'zh' ? '价格仅为情景假设；通过 WTP 与单位经济实验验证。' : 'Hypothesis only · validate with WTP and unit economics.'}</div>
  </section>;
}

export function CompetitorCard({ strategy, t, language }: Props) {
  return <section className="panel competitor-card" id="competition">
    <div className="panel-top"><div><div className="eyebrow">06 / ALTERNATIVES</div><h2>{t.competitors}</h2></div><span className="icon-chip"><span className="three-dots">···</span></span></div>
    <div className="competitor-table"><div className="competitor-table-head"><span>{language === 'zh' ? '竞品 / 客户' : 'COMPETITOR / CUSTOMER'}</span><span>{language === 'zh' ? '产品 / 定位' : 'PRODUCT / POSITION'}</span><span>{language === 'zh' ? '价格 / 渠道' : 'PRICE / CHANNEL'}</span><span>{language === 'zh' ? '信息 / 优劣势' : 'MESSAGE / EDGE'}</span></div>{strategy.competitors.map((item, index) => <div className="competitor-row" key={item.name}>
      <div className="competitor-name"><span className={`competitor-icon c${index + 1}`}>{item.name.slice(0, 1)}</span><div className="competitor-name-copy"><strong>{item.name}</strong><small>{item.customer}</small></div></div>
      <div className="competitor-product"><span className="competitor-cell-label">{language === 'zh' ? '产品 / 定位' : 'PRODUCT / POSITION'}</span><strong>{item.product}</strong><small>{item.position}</small></div>
      <div className="competitor-commercial"><span className="competitor-cell-label">{language === 'zh' ? '价格 / 渠道' : 'PRICE / CHANNEL'}</span><strong>{item.price}</strong><small>{item.channel}</small></div>
      <div className="competitor-wedge"><span className="competitor-cell-label">{language === 'zh' ? '信息 / 优劣势' : 'MESSAGE / EDGE'}</span><span>{item.message}</span><small><b>{language === 'zh' ? '优势' : 'Strength'}:</b> {item.strength} · <b>{language === 'zh' ? '弱点' : 'Weakness'}:</b> {item.weakness}</small></div>
    </div>)}</div>
    <div className="competitor-foot"><span className="source-dot" />{language === 'zh' ? '竞品描述与价格为示意信息，需实地核验。' : 'Illustrative competitor view · verify before use.'}</div>
  </section>;
}

export function ChannelCard({ strategy, t, language }: Props) {
  const stageColors = ['#bceb43', '#84c5ae', '#8cb2fb', '#d0a1e5'];
  return <section className="panel channel-card" id="channels">
    <div className="panel-top"><div><div className="eyebrow">07 / WHERE</div><h2>{t.channels}</h2></div><span className="icon-chip"><ArrowRight size={16} /></span></div>
    <div className="funnel-head">{['Awareness', 'Consideration', 'Conversion', 'Retention'].map((stage, index) => <span key={stage} style={{ '--stage-color': stageColors[index] } as React.CSSProperties}>{language === 'zh' ? ['认知', '考虑', '转化', '留存'][index] : stage}</span>)}</div>
    <div className="channel-list">{strategy.channels.map((channel, index) => <div className="channel-row" key={`${channel.stage}-${channel.channel}`}><div className="channel-stage"><i style={{ background: stageColors[index % stageColors.length] }} /><span>{language === 'zh' ? ({ Awareness: '认知', Consideration: '考虑', Conversion: '转化', Retention: '留存' }[channel.stage]) : channel.stage}</span></div><div className="channel-detail"><strong>{channel.channel}</strong><p>{channel.rationale}</p></div><span className="channel-arrow">↗</span></div>)}</div>
  </section>;
}

export function LaunchCard({ strategy, t, language }: Props) {
  const executionGroups = [
    { label: language === 'zh' ? '推广活动' : 'CAMPAIGNS', items: strategy.launch.campaigns },
    { label: language === 'zh' ? '内容资产' : 'CONTENT', items: strategy.launch.content },
    { label: language === 'zh' ? '销售手册' : 'SALES PLAYBOOK', items: strategy.launch.salesPlaybook },
    { label: language === 'zh' ? '验证实验' : 'EXPERIMENTS', items: strategy.launch.experiments },
  ];
  return <section className="panel launch-card" id="launch">
    <div className="panel-top"><div><div className="eyebrow">08 / WHEN</div><h2>{t.launch}</h2></div><div className="readiness-pill"><span>{t.readiness}</span><small>{language === 'zh' ? '示意' : 'ILLUSTRATIVE'}</small><strong>{strategy.launch.readiness}</strong></div></div>
    <div className="launch-track">{strategy.launch.phases.map((phase, index) => <div className="launch-phase" key={phase.name}><div className="phase-node"><span>0{index + 1}</span>{index < strategy.launch.phases.length - 1 && <i />}</div><div className="phase-copy"><div className="phase-meta"><strong>{phase.name}</strong><span>{phase.duration}</span></div><p>{phase.focus}</p></div></div>)}</div>
    <div className="execution-artifacts">{executionGroups.map((group) => <article className="execution-artifact" key={group.label}><div className="mini-heading">{group.label}</div><ul>{group.items.map((item) => <li key={item}>{item}</li>)}</ul></article>)}</div>
    <div className="kpi-area"><div className="mini-heading">{language === 'zh' ? '首轮成功指标' : 'FIRST-WAVE SUCCESS SIGNALS'}</div><div className="kpi-chips">{strategy.launch.kpis.map((kpi) => <span key={kpi}><Check size={12} />{kpi}</span>)}</div></div>
  </section>;
}

export function SystemMap({ t, language }: { t: Record<string, string>; language: Language }) {
  const layers = [
    { number: '01', title: language === 'zh' ? 'GTM 情报' : 'GTM Intelligence', desc: t.intelligenceDescription, labels: ['Market', 'Customer', 'Competitor', 'Trend'], color: 'map-green' },
    { number: '02', title: language === 'zh' ? 'GTM 推理' : 'GTM Reasoning', desc: t.reasoningDescription, labels: ['ICP', 'Position', 'Price', 'Motion'], color: 'map-blue' },
    { number: '03', title: language === 'zh' ? 'GTM 执行' : 'GTM Execution', desc: t.executionDescription, labels: ['Launch', 'Content', 'Sales', 'KPI'], color: 'map-violet' },
  ];
  return <section className="system-map" id="architecture">
    <div className="system-map-heading"><div><div className="eyebrow">CLOSED-LOOP GTM</div><h2>{t.modelLayers}</h2></div><div className="loop-mark"><i /><i /><i /></div></div>
    <div className="system-layers">{layers.map((layer, index) => <div className={`system-layer ${layer.color}`} key={layer.number}><div className="layer-index">{layer.number}</div><div className="layer-copy"><strong>{layer.title}</strong><p>{layer.desc}</p></div><div className="layer-labels">{layer.labels.map((label) => <span key={label}>{label}</span>)}</div>{index < layers.length - 1 && <div className="layer-arrow"><ArrowRight size={16} /></div>}</div>)}</div>
    <div className="iteration-loop"><span>DATA</span><i /><span>ITERATION</span><i /><span>INTELLIGENCE</span></div>
  </section>;
}
