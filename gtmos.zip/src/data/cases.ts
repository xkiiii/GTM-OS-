import type { DemoCase, GTMStrategy } from '../types/gtm';

const meetingStrategy: GTMStrategy = {
  market: {
    score: 82,
    confidence: 'Medium',
    summary: 'Strong workflow pull from revenue teams; crowded tooling makes a precise wedge essential.',
    evidence: [
      { dimension: 'market-size', label: 'Market size', value: 'Large category · illustrative', direction: 'neutral' },
      { dimension: 'growth', label: 'Market growth', value: 'Workflow AI tailwind · unverified', direction: 'positive' },
      { dimension: 'customer-maturity', label: 'Customer maturity', value: 'High SaaS / CRM adoption', direction: 'positive' },
      { dimension: 'competition', label: 'Competition', value: 'Crowded meeting tools', direction: 'risk' },
      { dimension: 'regulation', label: 'Regulation', value: 'Recording consent varies', direction: 'risk' },
      { dimension: 'distribution', label: 'Distribution', value: 'PLG + CRM ecosystems', direction: 'positive' },
      { dimension: 'localization', label: 'Localization', value: 'English-first buyer context', direction: 'neutral' },
      { dimension: 'unit-economics', label: 'Unit economics', value: 'Expansion upside · validate margin', direction: 'neutral' },
    ],
  },
  segment: {
    name: 'Revenue teams at scaling B2B SaaS companies',
    companyProfile: '20–200 employees · B2B SaaS · US-based growth stage',
    roles: ['VP / Head of Sales', 'RevOps lead', 'Frontline account executive'],
    pains: ['CRM updates steal selling time', 'Call learnings disappear between reps', 'Managers lack a consistent coaching signal'],
    triggers: ['New sales team or CRM rollout', 'Rising call volume', 'Pipeline quality becomes a board priority'],
    persona: 'The scaling revenue leader who needs every customer conversation to become reliable, usable CRM intelligence.',
  },
  motions: [
    { name: 'PLG', share: 45, role: 'Primary', rationale: 'A fast first-call insight makes self-serve activation demonstrable.' },
    { name: 'Sales assisted', share: 35, role: 'Secondary', rationale: 'Team-wide CRM workflows unlock expansion and multi-seat adoption.' },
    { name: 'Community', share: 20, role: 'Supporting', rationale: 'RevOps practitioners share templates and peer proof.' },
  ],
  competitors: [
    { name: 'Fireflies.ai', customer: 'Sales, support and cross-functional teams', product: 'Meeting notes, transcription, search and workflow integrations', position: 'Conversation capture and searchable meeting intelligence', price: 'Illustrative: freemium / per-seat tiers', channel: 'SEO · PLG · integrations', message: 'Illustrative: make every conversation searchable', strength: 'Broad meeting workflow coverage', weakness: 'Crowded note-taking category', },
    { name: 'Fathom', customer: 'Individuals and smaller revenue teams', product: 'Call recording, summaries and action items', position: 'Low-friction meeting summaries for daily work', price: 'Illustrative: free-to-paid', channel: 'Product-led · creator', message: 'Illustrative: meeting notes without manual work', strength: 'Low-friction individual value', weakness: 'Team workflow differentiation needed', },
    { name: 'Otter.ai', customer: 'Professionals and teams needing shared transcripts', product: 'Live transcription, searchable notes and meeting capture', position: 'Transcription and conversation capture', price: 'Illustrative: tiered subscription', channel: 'SEO · integrations', message: 'Illustrative: searchable transcripts, instantly', strength: 'Familiar transcription behavior', weakness: 'CRM action loop can be sharper', },
  ],
  positioning: {
    category: 'AI sales conversation intelligence',
    target: 'Revenue teams at 20–200 person B2B companies',
    problem: 'Every customer conversation creates work, but the useful context rarely reaches the CRM.',
    alternative: 'Manual note-taking, call recordings and generic meeting summaries',
    differentiation: 'Structured CRM-ready actions and coaching signals built around the sales workflow.',
    valueProposition: 'Turn every customer conversation into CRM intelligence.',
    message: 'Less admin after the call. More signal in the next one.',
  },
  pricing: {
    model: 'Seat-based SaaS · monthly subscription',
    recommendation: '$29 / seat / month',
    options: [
      { label: 'Growth', price: '$19', strategy: 'Adoption', note: 'Fastest team trial; constrain advanced CRM workflows.' },
      { label: 'Balanced', price: '$29', strategy: 'Recommended', note: 'Anchor value to reclaimed rep time and CRM hygiene.' },
      { label: 'Premium', price: '$49', strategy: 'Expansion', note: 'Bundle manager coaching and revenue analytics.' },
    ],
  },
  channels: [
    { stage: 'Awareness', channel: 'SEO + sales workflow content', rationale: 'Capture intent around CRM updates and call follow-up.' },
    { stage: 'Consideration', channel: 'Product Hunt + RevOps community', rationale: 'Let buyers experience the first useful call summary.' },
    { stage: 'Conversion', channel: 'Self-serve trial + sales-assisted demo', rationale: 'Prove a CRM action loop with one team in week one.' },
    { stage: 'Retention', channel: 'In-product activation + manager digest', rationale: 'Make repeat usage and team-wide adoption visible.' },
  ],
  launch: {
    readiness: 74,
    phases: [
      { name: 'Design partners', duration: 'Weeks 1–2', focus: 'Validate CRM write-back and capture 5 before/after workflows.' },
      { name: 'Private beta', duration: 'Weeks 3–5', focus: 'Instrument first-call activation, quality review and team invites.' },
      { name: 'Public launch', duration: 'Weeks 6–8', focus: 'Ship founder-led content, Product Hunt and assisted onboarding.' },
    ],
    campaigns: ['Run a first-call CRM cleanup week with five design-partner teams.', 'Launch with Product Hunt and a RevOps community workflow clinic.'],
    content: ['Publish a before/after CRM workflow teardown.', 'Ship a sales-manager activation guide and ROI calculator.'],
    salesPlaybook: ['Qualify by call volume, CRM fit and note-taking overhead.', 'Prove the CRM write-back loop with one team in the first week.'],
    experiments: ['Compare guided versus self-serve first-call activation.', 'Test $19 / $29 / $49 packaging against seat expansion.'],
    kpis: ['First-call activation', 'CRM action acceptance', 'Seats activated per account', 'Week-4 retained teams'],
  },
  assumptions: ['Illustrative opportunity score; validate with buyer interviews and current category data.', 'Pricing and competitor details are planning hypotheses, not a live price scrape.'],
};

const cameraStrategy: GTMStrategy = {
  market: {
    score: 76,
    confidence: 'Low',
    summary: 'A recognizable category with clear creator demand; retail reach and brand proof determine the launch ceiling.',
    evidence: [
      { dimension: 'market-size', label: 'Market size', value: 'Established category · illustrative', direction: 'neutral' },
      { dimension: 'growth', label: 'Market growth', value: 'Creator demand tailwind · hypothesis', direction: 'positive' },
      { dimension: 'customer-maturity', label: 'Customer maturity', value: 'High product familiarity', direction: 'positive' },
      { dimension: 'competition', label: 'Competition', value: 'Strong global incumbents', direction: 'risk' },
      { dimension: 'regulation', label: 'Regulation', value: 'EU product / battery rules', direction: 'neutral' },
      { dimension: 'distribution', label: 'Distribution', value: 'Retail + marketplaces + creators', direction: 'positive' },
      { dimension: 'localization', label: 'Localization', value: 'German language and local support', direction: 'neutral' },
      { dimension: 'unit-economics', label: 'Unit economics', value: 'Returns and hardware margin matter', direction: 'risk' },
    ],
  },
  segment: {
    name: 'Adventure creators and active outdoor enthusiasts',
    companyProfile: 'Consumer · enthusiast and creator segments · Germany-first distribution',
    roles: ['Outdoor creator', 'Action-sport enthusiast', 'Specialty retail buyer'],
    pains: ['Footage fails when conditions turn rough', 'Setup friction breaks the moment', 'Buyers struggle to compare real-world stabilization and workflow'],
    triggers: ['Travel or season start', 'New sport / creator format', 'Retail demo or trusted creator review'],
    persona: 'The adventure storyteller who wants footage they can trust and a workflow that gets from capture to publish quickly.',
  },
  motions: [
    { name: 'Retail', share: 45, role: 'Primary', rationale: 'Hands-on comparison reduces product uncertainty and earns trust.' },
    { name: 'Creator-led', share: 35, role: 'Secondary', rationale: 'Real-world footage demonstrates performance better than a spec sheet.' },
    { name: 'DTC / Amazon', share: 20, role: 'Supporting', rationale: 'Capture high-intent research and protect first-party learning.' },
  ],
  competitors: [
    { name: 'GoPro', customer: 'Outdoor athletes, travelers and action creators', product: 'Action cameras, mounts and capture software', position: 'Action camera category leader', price: 'Illustrative: premium hardware tiers', channel: 'Retail · DTC · creators', message: 'Illustrative: capture life in the moment', strength: 'High category recognition', weakness: 'A challenger needs a clear use-case wedge', },
    { name: 'Insta360', customer: 'Creators prioritizing immersive perspectives', product: '360° / action cameras and editing software', position: 'Immersive capture and creator workflow', price: 'Illustrative: product-family tiers', channel: 'DTC · Amazon · creators', message: 'Illustrative: create perspectives others cannot', strength: 'Distinctive capture formats', weakness: 'Learning curve and choice complexity', },
    { name: 'DJI', customer: 'Creators and outdoor consumers', product: 'Imaging cameras, gimbals and accessories', position: 'Imaging hardware ecosystem', price: 'Illustrative: premium hardware tiers', channel: 'Retail · DTC · partners', message: 'Illustrative: stable, high-quality mobile capture', strength: 'Imaging and accessory ecosystem', weakness: 'Brand story must travel across use cases', },
  ],
  positioning: {
    category: 'Adventure capture system',
    target: 'German outdoor creators and active travelers',
    problem: 'High-stakes moments happen in weather and movement that make reliable capture difficult.',
    alternative: 'Phone capture, incumbent action cameras and bulky camera rigs',
    differentiation: 'A fast-to-mount, dependable capture workflow with creator-ready edits.',
    valueProposition: 'Capture the moment. Publish the story.',
    message: 'Built for the shot you only get once.',
  },
  pricing: {
    model: 'Hardware margin · camera + accessory bundles',
    recommendation: '€349 camera kit · indicative',
    options: [
      { label: 'Core', price: '€279', strategy: 'Entry', note: 'Reduce first-purchase friction; keep the accessory set focused.' },
      { label: 'Creator kit', price: '€349', strategy: 'Recommended', note: 'Bundle mounts and workflow essentials to protect value.' },
      { label: 'Adventure bundle', price: '€449', strategy: 'Premium', note: 'Add batteries and specialty mounts for high-intent users.' },
    ],
  },
  channels: [
    { stage: 'Awareness', channel: 'Creator field tests + outdoor events', rationale: 'Show authentic footage in the conditions that matter.' },
    { stage: 'Consideration', channel: 'Retail demos + comparison content', rationale: 'Make mounting, stabilization and workflow tangible.' },
    { stage: 'Conversion', channel: 'Specialty retail + Amazon + DTC', rationale: 'Meet research intent with availability and clear bundles.' },
    { stage: 'Retention', channel: 'Creator community + accessory drops', rationale: 'Build repeat engagement around new activities and setups.' },
  ],
  launch: {
    readiness: 68,
    phases: [
      { name: 'Retail validation', duration: 'Weeks 1–3', focus: 'Test sell-in story, demo loop and top objections with pilot partners.' },
      { name: 'Creator seeding', duration: 'Weeks 4–6', focus: 'Recruit 12 local creators across distinct outdoor use cases.' },
      { name: 'Market launch', duration: 'Weeks 7–10', focus: 'Coordinate DTC, retail training, Amazon content and event sampling.' },
    ],
    campaigns: ['Seed a German outdoor field-test series with local micro-creators.', 'Run a specialty-retail demo weekend with a creator meet-up.'],
    content: ['Publish a German-language weatherproof capture guide.', 'Build stabilization, mounting and workflow comparison pages.'],
    salesPlaybook: ['Give retail associates a 90-second hands-on demo sequence.', 'Equip specialty shops with a sell-in and common-objections one-pager.'],
    experiments: ['Compare creator proof with retail-demo conversion.', 'Test creator-kit versus camera-only bundle attach rate.'],
    kpis: ['Retail sell-through', 'Creator-assisted product views', 'Bundle attach rate', 'Return reason mix'],
  },
  assumptions: ['Illustrative market score and channel mix; validate partner availability and category sell-through.', 'All competitor positioning and price references require current market verification.'],
};

const securityStrategy: GTMStrategy = {
  market: {
    score: 79,
    confidence: 'Medium',
    summary: 'Security priorities are strategically important; local trust, procurement fit and partner credibility shape entry.',
    evidence: [
      { dimension: 'market-size', label: 'Market size', value: 'Enterprise security spend · illustrative', direction: 'neutral' },
      { dimension: 'growth', label: 'Market growth', value: 'Cloud risk tailwind · unverified', direction: 'positive' },
      { dimension: 'customer-maturity', label: 'Customer maturity', value: 'High security capability', direction: 'positive' },
      { dimension: 'competition', label: 'Competition', value: 'Established global / local vendors', direction: 'risk' },
      { dimension: 'regulation', label: 'Regulation', value: 'Data and procurement fit matter', direction: 'risk' },
      { dimension: 'distribution', label: 'Distribution', value: 'Enterprise direct + local partners', direction: 'positive' },
      { dimension: 'localization', label: 'Localization', value: 'Japanese language and trust signals', direction: 'neutral' },
      { dimension: 'unit-economics', label: 'Unit economics', value: 'High ACV · long payback cycle', direction: 'risk' },
    ],
  },
  segment: {
    name: 'Mid-market and enterprise security teams',
    companyProfile: '500–5,000 employees · regulated or data-sensitive sectors · Japan',
    roles: ['CISO / security director', 'SOC leader', 'IT procurement and risk owner'],
    pains: ['Alert volume outpaces analyst capacity', 'Global tools can miss local procurement requirements', 'Proof-of-value takes too long to coordinate'],
    triggers: ['Security review or audit window', 'Incident or platform consolidation', 'Cloud transformation / regional expansion'],
    persona: 'The security leader who needs measurable risk reduction and a trusted implementation path, not another dashboard.',
  },
  motions: [
    { name: 'Enterprise sales', share: 50, role: 'Primary', rationale: 'Multi-stakeholder evaluation and a clear proof-of-value are central.' },
    { name: 'Partner-led', share: 35, role: 'Secondary', rationale: 'Local integrators provide context, trust and deployment capacity.' },
    { name: 'Executive content', share: 15, role: 'Supporting', rationale: 'Credible local expertise creates informed demand before outreach.' },
  ],
  competitors: [
    { name: 'Trend Micro', customer: 'Japanese enterprises and public-sector teams', product: 'Endpoint, network and cloud security portfolio', position: 'Established regional security vendor', price: 'Illustrative: enterprise contract', channel: 'Direct · partner ecosystem', message: 'Illustrative: trusted local protection across workloads', strength: 'Local familiarity and broad portfolio', weakness: 'A focused wedge must be explicit', },
    { name: 'CrowdStrike', customer: 'Global enterprises with cloud-first security teams', product: 'Cloud-native endpoint and threat response platform', position: 'Cloud-native endpoint security platform', price: 'Illustrative: enterprise contract', channel: 'Direct · partner ecosystem', message: 'Illustrative: detect and respond from one platform', strength: 'Strong global platform narrative', weakness: 'Local proof and procurement fit must be earned', },
    { name: 'Palo Alto Networks', customer: 'Large enterprises consolidating security stacks', product: 'Network, cloud and endpoint security platform', position: 'Broad security platform provider', price: 'Illustrative: enterprise contract', channel: 'Direct · channel partners', message: 'Illustrative: consolidate security across the platform', strength: 'Large platform breadth', weakness: 'Focused time-to-value can differentiate', },
  ],
  positioning: {
    category: 'Managed security decision and response platform',
    target: 'Security teams at Japanese enterprises with lean SOC capacity',
    problem: 'Teams need to resolve material incidents without adding noise or risk to existing operations.',
    alternative: 'Fragmented point tools, manual triage and platform expansion without workflow redesign',
    differentiation: 'A measurable, partner-enabled path from alert to verified action.',
    valueProposition: 'Help your security team act on the signal that matters.',
    message: 'A clearer path from alert to action — with a local team beside you.',
  },
  pricing: {
    model: 'Annual enterprise contract · scope-based platform + services',
    recommendation: '¥7.2M / year · indicative starting scope',
    options: [
      { label: 'Pilot', price: '¥1.8M', strategy: 'Proof', note: 'Time-boxed 8–10 week paid proof-of-value with agreed success criteria.' },
      { label: 'Core', price: '¥7.2M / yr', strategy: 'Recommended', note: 'Scope by protected environment and response workflow.' },
      { label: 'Platform', price: 'Custom', strategy: 'Expansion', note: 'Multi-business-unit deployment with partner services.' },
    ],
  },
  channels: [
    { stage: 'Awareness', channel: 'Local security roundtables + executive briefings', rationale: 'Earn relevance with concrete risk and operational language.' },
    { stage: 'Consideration', channel: 'Partner workshops + technical proof', rationale: 'Build trust and map to existing procurement requirements.' },
    { stage: 'Conversion', channel: 'ABM + paid proof-of-value', rationale: 'Focus on named accounts with sponsor, use case and exit criteria.' },
    { stage: 'Retention', channel: 'Partner success + quarterly risk reviews', rationale: 'Demonstrate outcome, adoption and next deployment opportunity.' },
  ],
  launch: {
    readiness: 71,
    phases: [
      { name: 'Localize & qualify', duration: 'Weeks 1–4', focus: 'Validate buying committee, partner capability and security requirements.' },
      { name: 'Land proof points', duration: 'Weeks 5–10', focus: 'Secure 2–3 design partners and measurable paid pilots.' },
      { name: 'Scale through partners', duration: 'Weeks 11–16', focus: 'Codify playbook, partner certification and referenceable outcomes.' },
    ],
    campaigns: ['Host an invitation-only security readiness roundtable with local partners.', 'Recruit design partners for a paid, evidence-led proof-of-value cohort.'],
    content: ['Publish a Japanese incident-response workflow brief.', 'Prepare a deployment, procurement and proof-of-value checklist.'],
    salesPlaybook: ['Qualify named accounts by incident trigger, sponsor and procurement path.', 'Agree an eight-week POC plan with baseline and verified outcome criteria.'],
    experiments: ['Compare partner-sourced and direct POC completion rates.', 'Measure triage time and analyst hours saved in the pilot cohort.'],
    kpis: ['Qualified named accounts', 'Pilot-to-contract rate', 'Days to first verified outcome', 'Partner-sourced pipeline'],
  },
  assumptions: ['Illustrative opportunity score and procurement path; confirm through Japanese buyer interviews.', 'Partner access, regulatory details and competitor pricing need current local research.'],
};

export const demoCases: DemoCase[] = [
  {
    id: 'meeting', name: 'AI Meeting Assistant', type: 'AI SaaS', product: 'AI meeting assistant', market: 'United States', marketLabel: 'US',
    model: 'Subscription', customerType: 'B2B', stage: '0 → 1', objective: 'Launch', acv: 348, budget: 100000,
    target: 'SMB · 20–200 employees', motion: 'PLG + Sales assisted', accent: '#bfeb49', icon: 'meeting',
    description: 'Turn every customer conversation into CRM intelligence.', strategy: meetingStrategy,
  },
  {
    id: 'camera', name: 'Action Camera', type: 'Consumer hardware', product: 'Action camera', market: 'Germany', marketLabel: 'DE',
    model: 'One-off', customerType: 'B2C', stage: '0 → 1', objective: 'Market entry', acv: 349, budget: 300000,
    target: 'Adventure creators & outdoor enthusiasts', motion: 'Retail + Creator-led', accent: '#d9a86c', icon: 'camera',
    description: 'Capture the moment. Publish the story.', strategy: cameraStrategy,
  },
  {
    id: 'security', name: 'Cybersecurity SaaS', type: 'Enterprise', product: 'Cybersecurity SaaS', market: 'Japan', marketLabel: 'JP',
    model: 'Subscription', customerType: 'B2B', stage: 'Expansion', objective: 'Market entry', acv: 48000, budget: 500000,
    target: 'Enterprise security teams · 500–5,000 employees', motion: 'Enterprise sales + Partner', accent: '#80aaff', icon: 'shield',
    description: 'A clearer path from alert to action.', strategy: securityStrategy,
  },
];

export function getCase(id: string): DemoCase {
  return demoCases.find((item) => item.id === id) ?? demoCases[0];
}
