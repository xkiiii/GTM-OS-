import type { GTMContext, MotionPlan } from '../types/gtm';

export interface WorkflowModule {
  id: string;
  title: string;
  weight: number;
  reason: string;
}

interface ContextSignals {
  domain: string;
  consumer: boolean;
  enterprise: boolean;
  developer: boolean;
  marketEntry: boolean;
  expansionMarket: boolean;
  targetLabel: string;
}

const clamp = (value: number, min = 50, max = 98) => Math.max(min, Math.min(max, Math.round(value)));

function classify(context: GTMContext): ContextSignals {
  const product = `${context.product} ${context.target}`.toLowerCase();
  const market = context.market.toLowerCase();
  const target = context.target.toLowerCase();
  const hardware = /camera|hardware|consumer electronics|device|wearable|smart home|action cam/i.test(product);
  const marketplace = context.businessModel === 'Marketplace' || /marketplace|two-sided|platform/i.test(product);
  const developer = /developer|coding|api|devtool|sdk|open.?source|devops|infrastructure/i.test(product);
  const fintech = /fintech|payment|banking|bank|insurance|金融|支付|银行/i.test(product);
  const education = /education|edtech|learning|course|school|university|教育|学习/i.test(product);
  const games = /game|gaming|esports|游戏/i.test(product);
  const cybersecurity = /cyber|security|zero trust|endpoint|siem|identity|安全|网络安全/i.test(product);
  const dtc = /dtc|direct.to.consumer|e.?commerce|retail|consumer brand|amazon seller|电商|零售/i.test(product);
  const app = /\bapp\b|mobile application|app store|应用/i.test(product);
  const aiProduct = /\bai\b|artificial intelligence|copilot|assistant|generative|llm|人工智能|智能助手/i.test(product);
  const targetEnterprise = /enterprise|large company|fortune|global account|1,?000\+|500\+|enterprise team|大型企业|集团|跨国/i.test(target);
  const targetSmall = /smb|small business|startup|founder|solo|individual|creator|small team|中小企业|初创|个人/i.test(target);
  const explicitEnterprise = /enterprise sales|inside sales|channel sales|abm|outbound/i.test(context.motion);
  const enterprise = context.acv >= 10000 || targetEnterprise || explicitEnterprise;
  const consumer = context.customerType !== 'B2B' || context.businessModel === 'One-off' || hardware || dtc || games || app;
  const homeMarket = /united states|\busa?\b|america|美国/i.test(market);
  const expansionMarket = !homeMarket || context.stage === 'Expansion';
  const targetLabel = context.target.trim().slice(0, 72) || 'the selected first segment';

  let domain = 'General B2B / digital product';
  if (marketplace) domain = 'Marketplace / platform';
  else if (hardware) domain = 'Consumer electronics';
  else if (fintech) domain = 'Fintech';
  else if (cybersecurity) domain = 'Cybersecurity SaaS';
  else if (developer) domain = 'Developer tools';
  else if (education) domain = 'Education / EdTech';
  else if (games) domain = 'Games / interactive media';
  else if (dtc) domain = 'DTC / retail';
  else if (app) domain = 'Consumer / mobile app';
  else if (aiProduct && context.businessModel !== 'One-off') domain = 'AI SaaS / software';
  else if (context.customerType === 'B2C') domain = 'B2C product';
  else if (context.businessModel === 'Subscription' || context.businessModel === 'Usage based') domain = 'B2B SaaS / subscription';

  return {
    domain,
    consumer,
    enterprise: enterprise || (context.customerType === 'B2B' && !targetSmall && /enterprise|bank|financial|government|telecom/i.test(product)),
    developer,
    marketEntry: context.objective === 'Market entry',
    expansionMarket,
    targetLabel,
  };
}

function canonicalMotion(raw: string): string {
  const value = raw.trim().toLowerCase().replace(/[–—]/g, '-');
  if (/\bplg\b|product[- ]led/.test(value)) return 'PLG';
  if (/self[- ]serve|self service/.test(value)) return 'Self serve';
  if (/inside sales/.test(value)) return 'Inside sales';
  if (/enterprise sales|sales[- ]led enterprise/.test(value)) return 'Enterprise sales';
  if (/channel sales/.test(value)) return 'Channel sales';
  if (/sales assisted|sales[- ]assisted/.test(value)) return 'Sales assisted';
  if (/partner/.test(value)) return 'Partner-led';
  if (/marketplace/.test(value)) return 'Marketplace-led';
  if (/retail/.test(value)) return 'Retail';
  if (/creator|influencer/.test(value)) return 'Creator-led';
  if (/community/.test(value)) return 'Community-led';
  if (/marketing/.test(value)) return 'Marketing-led';
  if (/dtc/.test(value)) return 'DTC';
  if (/abm|outbound/.test(value)) return 'ABM + outbound';
  return raw.trim();
}

function suggestedMotions(context: GTMContext, signals: ContextSignals): string[] {
  if (signals.domain === 'Consumer electronics' || signals.domain === 'DTC / retail') return ['Retail', 'Creator-led', 'DTC'];
  if (signals.domain === 'Marketplace / platform') return ['Marketplace-led', 'Partner-led', 'Community-led'];
  if (signals.domain === 'Games / interactive media') return ['Community-led', 'Creator-led', 'Marketing-led'];
  if (signals.domain === 'Education / EdTech') return ['Marketing-led', 'Community-led', 'Partner-led'];
  if (signals.domain === 'Fintech') return signals.enterprise ? ['Enterprise sales', 'Channel sales', 'Partner-led'] : ['PLG', 'Marketing-led', 'Partner-led'];
  if (signals.domain === 'Developer tools' || signals.developer) return ['PLG', 'Community-led', 'Enterprise sales'];
  if (signals.domain === 'Consumer / mobile app' || context.customerType !== 'B2B') return ['Marketing-led', 'Creator-led', 'Self serve'];
  if (signals.enterprise) return ['Enterprise sales', /japan|日本/i.test(context.market) ? 'Partner-led' : 'Inside sales', 'ABM + outbound'];
  return ['PLG', 'Sales assisted', 'Community-led'];
}

function rationaleFor(name: string, context: GTMContext, signals: ContextSignals): string {
  const stageNote: Record<GTMContext['stage'], string> = {
    '0 → 1': 'At 0→1, prioritize fast learning and direct customer evidence.',
    PMF: 'At PMF, use the motion to validate repeatable activation and retention.',
    Growth: 'At Growth, instrument unit economics and scale only the channels that repeat.',
    Expansion: 'At Expansion, prove localization, partner coverage and regional readiness.',
  };
  const budgetNote = context.budget < 50000
    ? ' A lean budget favors compounding, partner-assisted or high-intent paths.'
    : context.budget >= 300000
      ? ' The larger budget can support controlled multi-channel tests after a baseline is defined.'
      : '';
  const marketNote = signals.expansionMarket ? ` Validate local language, trust, regulation and distribution in ${context.market.trim() || 'the selected market'} before scaling.` : ` Use ${context.market.trim() || 'the selected market'} as the first-market reference and verify demand with customer research.`;
  const base: Record<string, string> = {
    PLG: 'Self-serve product value lets the target segment reach a first success moment before sales effort.',
    'Self serve': 'A low-friction evaluation path is efficient when buyers can understand value without a live sales gate.',
    'Inside sales': 'A focused sales team can qualify intent, guide evaluation and shorten a complex buying journey.',
    'Enterprise sales': 'High ACV, stakeholder complexity and procurement justify consultative enterprise selling.',
    'Channel sales': 'A channel-led route extends qualified coverage through established buyer access and service capacity.',
    'Sales assisted': 'Human support complements product adoption when onboarding, multi-seat expansion or proof is important.',
    'Partner-led': 'Trusted local or ecosystem partners reduce access, credibility and implementation friction.',
    'Marketplace-led': 'Marketplace distribution captures active intent and concentrates discovery where buyers already transact.',
    Retail: 'Retail makes hands-on discovery, shelf availability and local distribution part of the product experience.',
    'Creator-led': 'Creators make the product tangible through trusted, contextual demonstrations and audience fit.',
    'Community-led': 'Peer learning, shared proof and customer participation can compound trust at low marginal cost.',
    'Marketing-led': 'A coordinated brand, content and demand program creates category understanding before conversion.',
    DTC: 'Direct-to-consumer channels preserve customer insight, merchandising control and repeat-purchase relationships.',
    'ABM + outbound': 'Named-account selection aligns outbound effort to high-fit buying committees and measurable intent.',
  };
  return `${base[name] ?? `The explicitly selected “${name}” route is retained as the primary test.`} ${stageNote[context.stage]}${budgetNote}${marketNote}`;
}

export function planGTM(context: GTMContext): { motions: MotionPlan[]; modules: WorkflowModule[]; profile: string } {
  const signals = classify(context);
  const suggested = suggestedMotions(context, signals);
  const explicit = context.motion.split(/\s*\+\s*/).map((part) => part.trim()).filter(Boolean).map(canonicalMotion);
  const selected = explicit.length > 0 ? explicit.slice(0, 2) : suggested.slice(0, 2);
  const motionNames = [...selected];
  for (const candidate of suggested) {
    if (motionNames.length >= 3) break;
    if (!motionNames.includes(candidate)) motionNames.push(candidate);
  }
  const motionShares = context.budget < 25000 ? [55, 30, 15] : context.budget >= 300000 ? [45, 30, 25] : motionNames.length > 1 && explicit.length > 1 ? [55, 30, 15] : [50, 30, 20];
  const motions: MotionPlan[] = motionNames.slice(0, 3).map((name, index) => ({
    name,
    share: motionShares[index],
    role: index === 0 ? 'Primary' : index === 1 ? 'Secondary' : 'Supporting',
    rationale: rationaleFor(name, context, signals),
  }));

  const stageMarket = context.stage === '0 → 1' ? 8 : context.stage === 'Expansion' ? 10 : context.stage === 'Growth' ? -7 : 4;
  const objectiveMarket = context.objective === 'Market entry' ? 16 : context.objective === 'Repositioning' ? 8 : context.objective === 'Growth' ? -5 : 0;
  const targetComplexity = signals.enterprise ? 10 : /mid.market|medium business|中型/i.test(context.target) ? 5 : 0;
  const entryReason = signals.marketEntry ? 'The market-entry objective makes local opportunity and entry friction the first decision.' : signals.expansionMarket ? 'Regional expansion raises localization, trust and distribution questions.' : 'Keep market sizing tied to the current stage and evidence quality.';
  const targetReason = signals.enterprise ? `The selected segment (${signals.targetLabel}) requires account fit, buying roles and procurement evidence.` : context.stage === 'PMF' ? `At PMF, narrow ${signals.targetLabel} into a repeatable early-adopter cohort.` : `Use ${signals.targetLabel} to focus on reachable, high-signal buyers.`;
  const budgetReason = context.budget < 50000 ? 'The constrained budget favors high-intent, reusable and partner-assisted tests.' : context.budget >= 300000 ? 'The larger budget supports controlled channel expansion after a working baseline.' : 'Keep spend proportional to observed conversion and payback.';
  const stageReason: Record<GTMContext['stage'], string> = {
    '0 → 1': 'At 0→1, prioritize discovery, a narrow wedge and fast learning.',
    PMF: 'At PMF, test repeatability, pricing confidence and retention.',
    Growth: 'At Growth, prioritize efficient acquisition, scale and cohort economics.',
    Expansion: 'At Expansion, prioritize localization, competitive adaptation and partner readiness.',
  };

  const modules: WorkflowModule[] = [
    { id: 'market', title: 'Market opportunity', weight: clamp(67 + objectiveMarket + stageMarket + (signals.expansionMarket ? 4 : 0)), reason: entryReason },
    { id: 'segment', title: 'Target segment & ICP', weight: clamp((signals.enterprise ? 82 : 75) + targetComplexity + (context.stage === '0 → 1' || context.stage === 'PMF' ? 8 : 0)), reason: targetReason },
    { id: 'competition', title: 'Competition intelligence', weight: clamp(70 + (context.objective === 'Repositioning' ? 14 : 0) + (context.stage === 'Expansion' ? 9 : 0) + (signals.domain === 'Fintech' || signals.domain === 'Cybersecurity SaaS' ? 6 : 0)), reason: context.objective === 'Repositioning' ? 'Repositioning requires a sharper alternative map and credible differentiation.' : signals.expansionMarket ? 'Expansion requires local alternatives, procurement and channel coverage.' : 'Map substitutes and the customer’s current workaround, not just named vendors.' },
    { id: 'positioning', title: 'Positioning & messaging', weight: clamp(78 + (context.stage === '0 → 1' ? 8 : 0) + (context.objective === 'Repositioning' ? 12 : 0) + (signals.domain === 'Developer tools' || signals.domain === 'AI SaaS / software' ? 5 : 0)), reason: 'Translate the product wedge into language that matches the selected buyer and category.' },
    { id: 'pricing', title: 'Pricing strategy', weight: clamp(71 + (context.acv < 1000 ? 10 : 0) + (signals.enterprise ? 10 : 0) + (context.businessModel === 'One-off' ? 8 : 0) + (context.stage === 'Growth' ? 6 : 0)), reason: context.businessModel === 'One-off' ? 'For one-off products, test willingness to pay, channel margin and repeat-purchase economics.' : signals.enterprise ? 'For enterprise value, test contract scope, proof, payback and procurement fit.' : 'Connect price architecture to activation, retention and sustainable unit economics.' },
    { id: 'channel', title: 'Channel & growth motion', weight: clamp(76 + (signals.consumer ? 10 : 0) + (signals.domain === 'Marketplace / platform' ? 12 : 0) + (context.stage === 'Growth' ? 10 : 0) + (context.budget >= 300000 ? 4 : 0)), reason: `${budgetReason} The explicitly chosen ${motions[0]?.name ?? 'market'} motion anchors channel priorities.` },
    { id: 'launch', title: 'Launch, measurement & iteration', weight: clamp(74 + (context.objective === 'Launch' ? 12 : 0) + (context.stage === 'Growth' || context.stage === 'Expansion' ? 6 : 0) + (context.budget < 50000 ? 4 : 0)), reason: `${stageReason[context.stage]} Define a measurable next decision for each execution asset.` },
  ];

  const businessLabel = signals.enterprise ? 'enterprise' : signals.consumer ? 'consumer' : context.customerType.toLowerCase();
  const motionLabel = motions[0]?.name ?? 'context-led';
  const profile = `${signals.domain} · ${businessLabel} · ${context.stage} · ${motionLabel}`;
  return { motions, modules, profile };
}
