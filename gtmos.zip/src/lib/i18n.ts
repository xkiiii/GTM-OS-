import type { Language } from '../types/gtm';

const en = {
  workspace: 'Workspace', cases: 'Demo cases', playbook: 'Playbook', architecture: 'System map', settings: 'Preferences',
  aiNative: 'AI-NATIVE GTM OS', intelligence: 'INTELLIGENCE', decision: 'DECISION', execution: 'EXECUTION', iteration: 'ITERATION',
  launchWorkspace: 'Launch workspace', strategyOverview: 'Strategy overview', generatedBy: 'Decision brief',
  market: 'Market opportunity', target: 'Target segment', motion: 'GTM motion', positioning: 'Positioning', pricing: 'Pricing', channels: 'Channel mix', launch: 'Launch plan',
  generate: 'Generate strategy', generating: 'Building decision brief…', simulator: 'Decision simulator', compare: 'Compare scenarios',
  product: 'Product', targetMarket: 'Target market', businessModel: 'Business model', customer: 'Customer type', stage: 'Company stage', objective: 'Objective',
  annualValue: 'ACV / unit value', budget: 'Launch budget', targetSegment: 'Target segment', primaryMotion: 'Primary motion',
  decisionInputs: 'Change a decision', baseline: 'Baseline', scenario: 'Scenario', assumptions: 'Model assumptions', illustrative: 'Illustrative model · not a forecast',
  estimatedCac: 'Est. CAC', ltv: 'Illustrative LTV', ltvCac: 'LTV / CAC', conversion: 'Conversion', cycle: 'Sales cycle', margin: 'Gross margin', reach: 'Reach', days: 'days',
  evidence: 'Evidence signals', confidence: 'Confidence', competitors: 'Competitive set', valueStory: 'Value story', campaign: 'Funnel & channels',
  readiness: 'Launch readiness', weeks: 'Launch sequence', kpis: 'Success signals', modelLayers: 'One engine. Three layers.',
  intelligenceDescription: 'Market, customer, competitor and trend signals.', reasoningDescription: 'Turn context into choices: ICP, position, price and motion.', executionDescription: 'Make decisions real with a launch plan, campaigns and experiments.',
  noForecast: 'Illustrative assumptions — calibrate with customer research.', changeCase: 'Switch context', selected: 'Selected', poweredBy: 'Strategy generated with Manus AI', fallback: 'Showing the seeded case brief',
  retry: 'Try again', confidenceMedium: 'Medium', now: 'Live scenario', copied: 'Copied',
};

const zh: typeof en = {
  workspace: '工作台', cases: '演示案例', playbook: '策略手册', architecture: '系统地图', settings: '偏好设置',
  aiNative: 'AI 原生 GTM 操作系统', intelligence: '情报', decision: '决策', execution: '执行', iteration: '迭代',
  launchWorkspace: '市场进入工作台', strategyOverview: '策略总览', generatedBy: '决策简报',
  market: '市场机会', target: '目标客群', motion: 'GTM 路径', positioning: '定位', pricing: '定价', channels: '渠道组合', launch: '上市计划',
  generate: '生成策略', generating: '正在构建决策简报…', simulator: '决策模拟器', compare: '对比情景',
  product: '产品', targetMarket: '目标市场', businessModel: '商业模式', customer: '客户类型', stage: '公司阶段', objective: '目标',
  annualValue: '年合同额 / 单价', budget: '上市预算', targetSegment: '目标客群', primaryMotion: '主要路径',
  decisionInputs: '调整决策变量', baseline: '基线', scenario: '情景', assumptions: '模型假设', illustrative: '示意模型 · 非预测',
  estimatedCac: '预估获客成本', ltv: '示意 LTV', ltvCac: 'LTV / CAC', conversion: '转化率', cycle: '销售周期', margin: '毛利率', reach: '市场覆盖', days: '天',
  evidence: '证据信号', confidence: '置信度', competitors: '竞争格局', valueStory: '价值主张', campaign: '漏斗与渠道',
  readiness: '上市准备度', weeks: '上市节奏', kpis: '成功指标', modelLayers: '一个引擎，三层闭环。',
  intelligenceDescription: '市场、客户、竞品与趋势信号。', reasoningDescription: '将上下文转为选择：ICP、定位、价格与路径。', executionDescription: '通过上市计划、营销与实验推动决策落地。',
  noForecast: '示意假设——请用客户研究校准。', changeCase: '切换上下文', selected: '已选中', poweredBy: '由 Manus AI 生成策略', fallback: '当前展示预置案例简报',
  retry: '重试', confidenceMedium: '中', now: '即时情景', copied: '已复制',
};

export function getStrings(language: Language) {
  return language === 'zh' ? zh : en;
}
