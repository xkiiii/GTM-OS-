const currencies: Array<{ pattern: RegExp; code: string }> = [
  { pattern: /japan|日本/i, code: 'JPY' },
  { pattern: /germany|france|italy|spain|netherlands|ireland|portugal|finland|austria|belgium|德国|法国|意大利|西班牙/i, code: 'EUR' },
  { pattern: /united kingdom|\buk\b|britain|england|英国/i, code: 'GBP' },
  { pattern: /singapore|新加坡/i, code: 'SGD' },
  { pattern: /australia|澳大利亚/i, code: 'AUD' },
  { pattern: /new zealand|新西兰/i, code: 'NZD' },
  { pattern: /canada|加拿大/i, code: 'CAD' },
  { pattern: /india|印度/i, code: 'INR' },
  { pattern: /china|中国/i, code: 'CNY' },
  { pattern: /brazil|巴西/i, code: 'BRL' },
  { pattern: /mexico|墨西哥/i, code: 'MXN' },
  { pattern: /switzerland|瑞士/i, code: 'CHF' },
];
const usdPattern = /united states|\bus\b|usa|america|美国/i;

export function isCurrencyKnownForMarket(market: string): boolean {
  return usdPattern.test(market) || currencies.some(({ pattern }) => pattern.test(market));
}

export function currencyForMarket(market: string): string {
  if (usdPattern.test(market)) return 'USD';
  return currencies.find(({ pattern }) => pattern.test(market))?.code ?? 'USD';
}

export function formatMarketMoney(value: number, market: string): string {
  const currency = currencyForMarket(market);
  const formatted = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
    maximumFractionDigits: 0,
    notation: value >= 10000 ? 'compact' : 'standard',
  }).format(value);
  return isCurrencyKnownForMarket(market) ? formatted : `${formatted} USD ref.`;
}
