import type { DemoCase, SimulatorInputs, SimulatorMetrics } from '../types/gtm';

const clamp = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));

interface MotionProfile {
  cacMultiplier: number;
  cycleDays: number;
  baseConversion: number;
  reachModifier: number;
}

function profileForMotion(motion: string): MotionProfile {
  const normalized = motion.trim().toLowerCase();
  if (/enterprise|abm|outbound|account.?based/.test(normalized)) return { cacMultiplier: 3.1, cycleDays: 112, baseConversion: 3.1, reachModifier: -7 };
  if (/partner|channel|alliance|reseller|integrator/.test(normalized)) return { cacMultiplier: 2.35, cycleDays: 88, baseConversion: 3.9, reachModifier: 2 };
  if (/retail|store/.test(normalized)) return { cacMultiplier: 1.55, cycleDays: 38, baseConversion: 4.8, reachModifier: 7 };
  if (/creator|influencer/.test(normalized)) return { cacMultiplier: 1.18, cycleDays: 24, baseConversion: 5.3, reachModifier: 10 };
  if (/marketplace|amazon|d2c|direct.to.consumer/.test(normalized)) return { cacMultiplier: 0.96, cycleDays: 16, baseConversion: 6.8, reachModifier: 8 };
  if (/sales.?assist|inside.?sales/.test(normalized)) return { cacMultiplier: 1.12, cycleDays: 46, baseConversion: 5.8, reachModifier: 0 };
  if (/community/.test(normalized)) return { cacMultiplier: 0.74, cycleDays: 21, baseConversion: 6.5, reachModifier: 6 };
  if (/content|executive/.test(normalized)) return { cacMultiplier: 0.86, cycleDays: 30, baseConversion: 6.2, reachModifier: 7 };
  if (/plg|self.?serve|product.led/.test(normalized)) return { cacMultiplier: 0.72, cycleDays: 18, baseConversion: 7.2, reachModifier: 10 };
  return { cacMultiplier: 1.05, cycleDays: 36, baseConversion: 5.8, reachModifier: 0 };
}

export function defaultSimulatorInputs(item: DemoCase): SimulatorInputs {
  const price = item.id === 'meeting' ? 29 : item.id === 'camera' ? 349 : 48000;
  return { price, budget: item.budget, target: item.target, market: item.market, motion: item.motion.split(' + ')[0] };
}

export function calculateMetrics(item: DemoCase, input: SimulatorInputs): SimulatorMetrics {
  const motion = profileForMotion(input.motion);
  const enterpriseTarget = /enterprise|1,000\+|5,000|500\+/i.test(input.target);
  const midMarket = /mid.?market/i.test(input.target);
  const targetCost = enterpriseTarget ? 2.5 : midMarket ? 1.55 : 1;
  const marketCost = /japan|日本/i.test(input.market) ? 1.24 : /germany|德国/i.test(input.market) ? 1.12 : 1;
  const hardware = item.model === 'One-off';
  const baselinePrice = item.id === 'meeting' ? 29 : hardware ? 349 : 48000;
  const priceRatio = Math.max(0.25, input.price / baselinePrice);
  const scaleFactor = clamp(Math.sqrt(100000 / Math.max(10000, input.budget)), 0.5, 2.2);
  const baseCAC = hardware ? 86 : enterpriseTarget ? 3250 : midMarket ? 1450 : 54;
  const cac = Math.round(baseCAC * motion.cacMultiplier * targetCost * marketCost * scaleFactor * Math.pow(priceRatio, 0.11));
  const conversion = Number(clamp(motion.baseConversion * Math.pow(1 / priceRatio, 0.16) * (enterpriseTarget ? 0.78 : midMarket ? 0.9 : 1) * (marketCost > 1.1 ? 0.91 : 1), 0.7, 14).toFixed(1));
  const salesCycle = Math.round(motion.cycleDays * (enterpriseTarget ? 1.34 : midMarket ? 1.18 : 1) * (/japan|日本/i.test(input.market) ? 1.18 : 1));
  const grossMargin = Math.round(clamp((hardware ? 42 : 84) - (priceRatio < 0.85 ? 6 : priceRatio > 1.4 ? -3 : 0), 22, 92));
  const lifetimeYears = enterpriseTarget ? 3 : midMarket ? 2.5 : 2;
  const annualValue = item.acv > 10000 ? input.price : input.price * 12;
  const ltv = Math.round((hardware ? input.price * 1.35 : annualValue * lifetimeYears) * grossMargin / 100);
  const ltvCac = Number((ltv / Math.max(cac, 1)).toFixed(1));
  const reach = Math.round(clamp(10 + 13 * Math.log10(Math.max(0.25, input.budget / 50000)) + (consumerMode(item) ? 15 : 0) + motion.reachModifier - (enterpriseTarget ? 8 : 0), 5, 92));
  return { cac, ltv, ltvCac, conversion, salesCycle, grossMargin, reach };
}

export function consumerMode(item: DemoCase): boolean {
  return item.customerType !== 'B2B' || item.model === 'One-off';
}

export function deltaLabel(current: number, baseline: number, lowerIsBetter = false): { text: string; tone: 'good' | 'bad' | 'flat' } {
  if (current === baseline) return { text: 'Baseline', tone: 'flat' };
  const pct = Math.round(((current - baseline) / Math.max(1, baseline)) * 100);
  const beneficial = lowerIsBetter ? pct < 0 : pct > 0;
  return { text: `${pct > 0 ? '+' : ''}${pct}%`, tone: beneficial ? 'good' : 'bad' };
}
