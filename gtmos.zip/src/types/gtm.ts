export type Language = 'en' | 'zh';
export type CustomerType = 'B2B' | 'B2C' | 'B2B2C';
export type BusinessModel = 'Subscription' | 'Usage based' | 'One-off' | 'Marketplace';
export type Stage = '0 → 1' | 'PMF' | 'Growth' | 'Expansion';
export type Objective = 'Market entry' | 'Launch' | 'Growth' | 'Repositioning';
export type SalesMotion = 'PLG' | 'Self serve' | 'Inside sales' | 'Sales assisted' | 'Enterprise sales' | 'Channel sales' | 'Partner-led' | 'Marketing-led' | 'Community-led' | 'Retail' | 'Creator-led' | 'Marketplace-led';

export interface GTMContext {
  product: string;
  market: string;
  businessModel: BusinessModel;
  customerType: CustomerType;
  stage: Stage;
  objective: Objective;
  acv: number;
  budget: number;
  target: string;
  motion: string;
  caseId: string;
}

export interface MotionPlan {
  name: string;
  share: number;
  role: 'Primary' | 'Secondary' | 'Supporting';
  rationale: string;
}

export type MarketDimension = 'market-size' | 'growth' | 'customer-maturity' | 'competition' | 'regulation' | 'distribution' | 'localization' | 'unit-economics';

export interface MarketEvidence {
  dimension: MarketDimension;
  label: string;
  value: string;
  direction: 'positive' | 'neutral' | 'risk';
}

export interface Competitor {
  name: string;
  customer: string;
  product: string;
  position: string;
  price: string;
  channel: string;
  message: string;
  strength: string;
  weakness: string;
}

export interface PriceOption {
  label: string;
  price: string;
  strategy: string;
  note: string;
}

export interface ChannelPlan {
  stage: 'Awareness' | 'Consideration' | 'Conversion' | 'Retention';
  channel: string;
  rationale: string;
}

export interface GTMStrategy {
  market: {
    score: number;
    confidence: 'High' | 'Medium' | 'Low';
    summary: string;
    evidence: MarketEvidence[];
  };
  segment: {
    name: string;
    companyProfile: string;
    roles: string[];
    pains: string[];
    triggers: string[];
    persona: string;
  };
  motions: MotionPlan[];
  competitors: Competitor[];
  positioning: {
    category: string;
    target: string;
    problem: string;
    alternative: string;
    differentiation: string;
    valueProposition: string;
    message: string;
  };
  pricing: {
    model: string;
    recommendation: string;
    options: PriceOption[];
  };
  channels: ChannelPlan[];
  launch: {
    readiness: number;
    phases: { name: string; duration: string; focus: string }[];
    campaigns: string[];
    content: string[];
    salesPlaybook: string[];
    experiments: string[];
    kpis: string[];
  };
  assumptions: string[];
}

export interface DemoCase {
  id: string;
  name: string;
  type: string;
  product: string;
  market: string;
  marketLabel: string;
  model: BusinessModel;
  customerType: CustomerType;
  stage: Stage;
  objective: Objective;
  acv: number;
  budget: number;
  target: string;
  motion: string;
  accent: string;
  icon: 'meeting' | 'camera' | 'shield';
  description: string;
  strategy: GTMStrategy;
}

export interface SimulatorInputs {
  price: number;
  budget: number;
  target: string;
  market: string;
  motion: string;
}

export interface SimulatorMetrics {
  cac: number;
  ltv: number;
  ltvCac: number;
  conversion: number;
  salesCycle: number;
  grossMargin: number;
  reach: number;
}
