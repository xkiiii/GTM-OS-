import { useEffect, useMemo, useState } from 'react';
import { Activity, ArrowRight, BarChart3, BookOpen, Camera, Check, ChevronDown, CircleHelp, Compass, Globe2, Layers, Menu, Network, Search, Settings2, Shield, Sparkles, Target, Users, Video, X } from 'lucide-react';
import { demoCases, getCase } from './data/cases';
import { planGTM } from './lib/context';
import { currencyForMarket, isCurrencyKnownForMarket } from './lib/currency';
import { getStrings } from './lib/i18n';
import { defaultSimulatorInputs } from './lib/simulator';
import SimulatorPanel from './components/SimulatorPanel';
import IterationPanel from './components/IterationPanel';
import { ChannelCard, CompetitorCard, LaunchCard, MarketCard, MotionCard, PositioningCard, PricingCard, SegmentCard, SystemMap } from './components/StrategySections';
import type { BusinessModel, CustomerType, DemoCase, GTMContext, GTMStrategy, Language, Objective, SalesMotion, SimulatorInputs, Stage } from './types/gtm';

const modelOptions: BusinessModel[] = ['Subscription', 'Usage based', 'One-off', 'Marketplace'];
const stageOptions: Stage[] = ['0 → 1', 'PMF', 'Growth', 'Expansion'];
const objectiveOptions: Objective[] = ['Market entry', 'Launch', 'Growth', 'Repositioning'];
const motionOptions: SalesMotion[] = ['PLG', 'Self serve', 'Inside sales', 'Sales assisted', 'Enterprise sales', 'Channel sales', 'Partner-led', 'Marketing-led', 'Community-led', 'Retail', 'Creator-led', 'Marketplace-led'];
const workflowSteps = {
  en: [
    ['Business Context', '#context'], ['Market', '#market'], ['Segment', '#segment'], ['ICP', '#icp'],
    ['Competition', '#competition'], ['Positioning', '#positioning'], ['Pricing', '#pricing'], ['Channel', '#channels'],
    ['Growth Motion', '#motion'], ['Launch Plan', '#launch'], ['Measurement', '#measurement'], ['Iteration', '#iteration'],
  ],
  zh: [
    ['业务上下文', '#context'], ['市场', '#market'], ['客群', '#segment'], ['ICP', '#icp'],
    ['竞品', '#competition'], ['定位', '#positioning'], ['定价', '#pricing'], ['渠道', '#channels'],
    ['增长路径', '#motion'], ['上市计划', '#launch'], ['测量', '#measurement'], ['迭代', '#iteration'],
  ],
} as const;

function contextFrom(item: DemoCase): GTMContext {
  return { product: item.product, market: item.market, businessModel: item.model, customerType: item.customerType, stage: item.stage, objective: item.objective, acv: item.acv, budget: item.budget, target: item.target, motion: item.motion, caseId: item.id };
}

function CaseGlyph({ item, size = 17 }: { item: DemoCase; size?: number }) {
  const common = { size, strokeWidth: 1.7 };
  if (item.icon === 'camera') return <Camera {...common} />;
  if (item.icon === 'shield') return <Shield {...common} />;
  return <Video {...common} />;
}

function App() {
  const [language, setLanguage] = useState<Language>(() => localStorage.getItem('gtm-language') === 'zh' ? 'zh' : 'en');
  const [caseId, setCaseId] = useState('meeting');
  const [brief, setBrief] = useState<GTMContext>(() => contextFrom(getCase('meeting')));
  const [simInputs, setSimInputs] = useState<SimulatorInputs>(() => defaultSimulatorInputs(getCase('meeting')));
  const [aiStrategy, setAiStrategy] = useState<GTMStrategy | null>(null);
  const [aiModel, setAiModel] = useState('');
  const [aiPlanner, setAiPlanner] = useState<ReturnType<typeof planGTM> | null>(null);
  const [aiState, setAiState] = useState<'seed' | 'running' | 'success' | 'error'>('seed');
  const [error, setError] = useState('');
  const [errorKind, setErrorKind] = useState<'input' | 'rate-limit' | 'service'>('service');
  const [mobileMenu, setMobileMenu] = useState(false);
  const t = getStrings(language);
  const selectedCase = getCase(caseId);
  const seedContext = contextFrom(selectedCase);
  const isUneditedSeed = (Object.keys(seedContext) as (keyof GTMContext)[]).every((key) => seedContext[key] === brief[key]);
  const strategyTitle = brief.product.trim() || selectedCase.name;
  const strategyDescription = isUneditedSeed ? selectedCase.description : `${brief.target} · ${brief.market} · ${brief.stage} · ${brief.objective}`;
  const strategy = aiStrategy ?? selectedCase.strategy;
  const planner = useMemo(() => aiPlanner ?? planGTM(brief), [aiPlanner, brief]);
  const displayedMotions = aiStrategy?.motions ?? planner.motions;
  const simulationItem: DemoCase = useMemo(() => ({ ...selectedCase, market: brief.market, model: brief.businessModel, customerType: brief.customerType, target: brief.target, budget: brief.budget, acv: brief.acv, motion: brief.motion }), [selectedCase, brief]);
  const currency = currencyForMarket(brief.market);
  const currencyLabel = isCurrencyKnownForMarket(brief.market) ? currency : language === 'zh' ? 'USD 参考' : 'USD ref.';
  const invalidFields = {
    product: brief.product.trim().length < 2 || brief.product.length > 160,
    market: brief.market.trim().length < 2 || brief.market.length > 100,
    target: brief.target.trim().length < 2 || brief.target.length > 240,
    acv: !Number.isFinite(brief.acv) || brief.acv <= 0 || brief.acv > 100000000,
    budget: !Number.isFinite(brief.budget) || brief.budget <= 0 || brief.budget > 100000000,
  };
  const showInputErrors = aiState === 'error' && errorKind === 'input';
  const errorHeading = language === 'zh'
    ? errorKind === 'input' ? '请检查 launch brief 的必填字段' : errorKind === 'rate-limit' ? '请求较频繁，请稍后重试' : 'AI 服务暂不可用；已保留当前案例预览'
    : errorKind === 'input' ? 'Check the required launch brief fields' : errorKind === 'rate-limit' ? 'Too many requests; wait before retrying' : 'AI is temporarily unavailable; the case preview is preserved';
  const errorButton = language === 'zh' ? (errorKind === 'rate-limit' ? '稍后重试' : t.retry) : (errorKind === 'rate-limit' ? 'Retry after waiting' : t.retry);

  useEffect(() => {
    setBrief(contextFrom(getCase(caseId)));
    setSimInputs(defaultSimulatorInputs(getCase(caseId)));
    setAiStrategy(null);
    setAiModel('');
    setAiPlanner(null);
    setAiState('seed');
    setError('');
  }, [caseId]);

  useEffect(() => {
    localStorage.setItem('gtm-language', language);
    document.documentElement.lang = language === 'zh' ? 'zh-CN' : 'en';
  }, [language]);

  const updateBrief = <K extends keyof GTMContext>(key: K, value: GTMContext[K]) => {
    setBrief((current) => ({ ...current, [key]: value }));
    setSimInputs((current) => {
      const next = { ...current };
      if (key === 'market') next.market = String(value);
      if (key === 'target') next.target = String(value);
      if (key === 'budget') next.budget = Number(value);
      if (key === 'motion') next.motion = String(value).split(' + ')[0];
      if (key === 'acv') {
        next.price = Math.round(current.price * (Number(value) / Math.max(1, brief.acv)));
      }
      if (key === 'businessModel' && (value === 'One-off') !== (brief.businessModel === 'One-off')) {
        next.price = value === 'One-off'
          ? Math.min(900, Math.max(100, Math.round(brief.acv)))
          : Math.min(brief.acv > 10000 ? 150000 : 99, Math.max(10, current.price));
      }
      const hardware = key === 'businessModel' ? value === 'One-off' : brief.businessModel === 'One-off';
      const acv = key === 'acv' ? Number(value) : brief.acv;
      const minPrice = hardware ? 100 : acv > 10000 ? 10000 : 10;
      const maxPrice = hardware ? 900 : acv > 10000 ? 150000 : 99;
      if (key === 'acv' || key === 'businessModel') next.price = Math.min(maxPrice, Math.max(minPrice, next.price));
      return next;
    });
    setAiStrategy(null);
    setAiPlanner(null);
    setAiState('seed');
    setError('');
  };

  const handleGenerate = async () => {
    if (Object.values(invalidFields).some(Boolean)) {
      const invalidLabels = [
        invalidFields.product && (language === 'zh' ? '产品' : 'product'),
        invalidFields.market && (language === 'zh' ? '目标市场' : 'target market'),
        invalidFields.target && (language === 'zh' ? '目标客群' : 'target segment'),
        invalidFields.acv && (language === 'zh' ? 'ACV / 单价' : 'ACV / unit value'),
        invalidFields.budget && (language === 'zh' ? '上市预算' : 'launch budget'),
      ].filter(Boolean).join(language === 'zh' ? '、' : ', ');
      setErrorKind('input');
      setAiState('error');
      setError(language === 'zh' ? `请修正以下字段后再生成：${invalidLabels}。` : `Complete valid values for: ${invalidLabels}.`);
      return;
    }
    setAiState('running');
    setError('');
    setErrorKind('service');
    try {
      const response = await fetch('/api/strategy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ context: brief, language }),
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) {
        if (response.status === 400 || payload.code === 'invalid_context') {
          setErrorKind('input');
          throw new Error(language === 'zh' ? '产品、市场、客群或数值未通过校验；请修正高亮字段。' : 'Some launch brief values did not pass validation; check the highlighted fields.');
        }
        if (response.status === 429 || payload.code === 'rate_limited') {
          setErrorKind('rate-limit');
          throw new Error(language === 'zh' ? '生成请求过于频繁，请稍等几分钟后再试。' : payload.error || 'Wait a few minutes before retrying.');
        }
        setErrorKind('service');
        throw new Error(payload.error || 'Strategy generation is temporarily unavailable.');
      }
      if (!payload.strategy?.market || !payload.strategy?.positioning) throw new Error('The AI response was incomplete. Your brief is still here; retry or use the case preview.');
      setAiStrategy(payload.strategy as GTMStrategy);
      if (payload.planner && typeof payload.planner.profile === 'string' && Array.isArray(payload.planner.motions) && Array.isArray(payload.planner.modules)) {
        setAiPlanner(payload.planner as ReturnType<typeof planGTM>);
      }
      setAiModel(String(payload.model ?? 'Manus AI'));
      setAiState('success');
    } catch (cause) {
      setAiState('error');
      setError(cause instanceof Error ? cause.message : 'Could not reach the strategy service.');
    }
  };

  const generatedLabel = aiState === 'success'
    ? `${t.poweredBy} · ${aiModel}`
    : aiState === 'error'
      ? t.fallback
      : language === 'zh' ? '预置案例为英文 · 可生成中文 AI 策略' : 'Seeded demo brief · generate with AI';

  const fieldLabel = (en: string, zh: string) => language === 'zh' ? zh : en;
  const navItems = [
    { href: '#overview', label: t.workspace, icon: Compass },
    { href: '#market', label: t.market, icon: BarChart3 },
    { href: '#positioning', label: t.positioning, icon: Target },
    { href: '#channels', label: t.channels, icon: Network },
    { href: '#simulator', label: t.simulator, icon: Activity },
  ];
  const showSidebar = mobileMenu ? 'sidebar mobile-open' : 'sidebar';

  return (
    <div className="app-shell">
      <aside className={showSidebar}>
        <div className="brand-lockup"><div className="brand-mark"><svg viewBox="0 0 40 40" aria-hidden="true"><path d="M10 14.2 20 8.5l10 5.7v11.6L20 31.5 10 25.8V14.2Z" /><path d="M10 14.2 20 20l10-5.8M20 20v11.5" /><circle cx="10" cy="14.2" r="2.4" /><circle cx="20" cy="8.5" r="2.4" /><circle cx="30" cy="14.2" r="2.4" /><circle cx="30" cy="25.8" r="2.4" /><circle cx="20" cy="31.5" r="2.4" /><circle cx="10" cy="25.8" r="2.4" /><circle cx="20" cy="20" r="3" /></svg></div><div><strong>GTM<span>OS</span></strong><small>DECISION WORKSPACE</small></div><button className="sidebar-close" aria-label="Close navigation" onClick={() => setMobileMenu(false)}><X size={17} /></button></div>
        <div className="workspace-switch"><div className="workspace-avatar">G</div><div className="workspace-name"><strong>Growth Studio</strong><span>Portfolio workspace</span></div><ChevronDown size={15} /></div>
        <div className="side-label">{language === 'zh' ? '工作区' : 'WORKSPACE'}</div>
        <nav className="side-nav">{navItems.map(({ href, label, icon: Icon }, index) => <a key={href} href={href} className={index === 0 ? 'side-link active' : 'side-link'} onClick={() => setMobileMenu(false)}><Icon size={16} strokeWidth={1.8} /><span>{label}</span>{index === 0 && <span className="nav-indicator" />}</a>)}</nav>
        <div className="side-divider" />
        <div className="side-label case-label">{language === 'zh' ? '案例库' : 'DEMO CASES'}<span>03</span></div>
        <div className="case-nav">{demoCases.map((item, index) => <button key={item.id} className={caseId === item.id ? 'case-link selected' : 'case-link'} onClick={() => { setCaseId(item.id); setMobileMenu(false); }}><span className={`case-glyph glyph-${item.icon}`}><CaseGlyph item={item} size={16} /></span><span className="case-link-copy"><strong>{item.name}</strong><small>{item.type}</small></span>{caseId === item.id && <span className="case-active-dot" />}</button>)}</div>
        <div className="sidebar-bottom"><div className="sidebar-bottom-links"><a href="#architecture"><Layers size={15} />{t.architecture}</a><button onClick={() => setLanguage(language === 'en' ? 'zh' : 'en')}><Globe2 size={15} />{language === 'en' ? '中文 / Chinese' : 'English / 英文'}</button></div><div className="profile-row"><div className="profile-avatar">GS</div><div><strong>Growth Studio</strong><span>Product strategy</span></div><Settings2 size={16} /></div></div>
      </aside>
      {mobileMenu && <button className="mobile-scrim" aria-label="Close navigation" onClick={() => setMobileMenu(false)} />}

      <main className="main-area">
        <header className="topbar"><div className="topbar-left"><button className="mobile-menu-button" aria-label="Open navigation" onClick={() => setMobileMenu(true)}><Menu size={19} /></button><div className="breadcrumbs"><span>{language === 'zh' ? '项目' : 'PROJECTS'}</span><b>/</b><strong>{strategyTitle}</strong></div></div><div className="topbar-right"><div className="live-workspace"><span className="live-dot" />{language === 'zh' ? '本地工作区' : 'WORKSPACE LIVE'}</div><button className="icon-button search-button" aria-label="Search"><Search size={17} /></button><button className="language-button" onClick={() => setLanguage(language === 'en' ? 'zh' : 'en')}><Globe2 size={15} />{language === 'en' ? 'EN' : '中文'}</button><button className="help-button" aria-label="Help"><CircleHelp size={17} /></button></div></header>

        <div className="page-content" id="overview">
          <div className="page-kicker"><span className="kicker-line" />{language === 'zh' ? 'AI 原生市场进入决策' : 'AI-NATIVE GO-TO-MARKET DECISIONS'}<span className="kicker-id">01 — 03</span></div>
          <section className="hero-row"><div className="hero-copy"><h1>{language === 'zh' ? <>让每一次<br /><em>市场进入决策</em>清晰可见。</> : <>Make every launch<br /><em>decision visible.</em></>}</h1><p>{language === 'zh' ? '从市场情报到上市行动，把 GTM 变成一个持续迭代的决策系统。' : 'From market signal to launch motion. Turn GTM into a decision system that learns.'}</p></div><div className="hero-aside"><div className="hero-aside-mark"><span>WHO</span><i /><span>WHY</span><i /><span>WHAT</span><i /><span>WHERE</span><i /><span>HOW</span><i /><span>WHEN</span></div><span className="hero-aside-caption">{language === 'zh' ? '六个问题 · 一套引擎' : 'SIX QUESTIONS · ONE ENGINE'}</span></div></section>

          <section className="context-panel" id="context" aria-label="GTM context brief">
            <div className="context-panel-head"><div><div className="eyebrow">01 / CONTEXT ENGINE</div><h2>{language === 'zh' ? '先定义要做的决策。' : 'Set the decision context.'}</h2></div><span className="context-status"><i />{language === 'zh' ? '上下文就绪' : 'CONTEXT READY'}</span></div>
            <div className="brief-grid">
              <label className="brief-field span-2"><span>{fieldLabel('PRODUCT', '产品')}</span><input required maxLength={160} aria-invalid={showInputErrors && invalidFields.product} value={brief.product} onChange={(event) => updateBrief('product', event.target.value)} placeholder="What are you launching?" /></label>
              <label className="brief-field"><span>{fieldLabel('TARGET MARKET', '目标市场')}</span><input required list="context-market-options" maxLength={100} aria-invalid={showInputErrors && invalidFields.market} value={brief.market} onChange={(event) => updateBrief('market', event.target.value)} placeholder={language === 'zh' ? '输入任意市场' : 'Type any market'} /><datalist id="context-market-options"><option value="United States" /><option value="Germany" /><option value="Japan" /><option value="United Kingdom" /><option value="Singapore" /><option value="Southeast Asia" /></datalist></label>
              <label className="brief-field"><span>{fieldLabel('BUSINESS MODEL', '商业模式')}</span><select value={brief.businessModel} onChange={(event) => updateBrief('businessModel', event.target.value as BusinessModel)}>{modelOptions.map((option) => <option key={option}>{option}</option>)}</select></label>
              <label className="brief-field"><span>{fieldLabel('CUSTOMER', '客户类型')}</span><select value={brief.customerType} onChange={(event) => updateBrief('customerType', event.target.value as CustomerType)}><option>B2B</option><option>B2C</option><option>B2B2C</option></select></label>
              <label className="brief-field"><span>{fieldLabel('STAGE', '阶段')}</span><select value={brief.stage} onChange={(event) => updateBrief('stage', event.target.value as Stage)}>{stageOptions.map((option) => <option key={option}>{option}</option>)}</select></label>
              <label className="brief-field"><span>{fieldLabel('OBJECTIVE', '目标')}</span><select value={brief.objective} onChange={(event) => updateBrief('objective', event.target.value as Objective)}>{objectiveOptions.map((option) => <option key={option}>{option}</option>)}</select></label>
              <label className="brief-field span-2"><span>{fieldLabel('TARGET SEGMENT', '目标客群')}</span><input required maxLength={240} aria-invalid={showInputErrors && invalidFields.target} value={brief.target} onChange={(event) => updateBrief('target', event.target.value)} /></label>
              <label className="brief-field"><span>{fieldLabel('ACV / UNIT VALUE', '年合同额 / 单价')} <small>({currencyLabel})</small></span><input required type="number" min="1" max="100000000" aria-invalid={showInputErrors && invalidFields.acv} value={brief.acv} onChange={(event) => updateBrief('acv', Number(event.target.value) || 1)} /></label>
              <label className="brief-field"><span>{fieldLabel('LAUNCH BUDGET', '上市预算')} <small>({currencyLabel})</small></span><input required type="number" min="10000" max="100000000" step="10000" aria-invalid={showInputErrors && invalidFields.budget} value={brief.budget} onChange={(event) => updateBrief('budget', Number(event.target.value) || 10000)} /></label>
              <label className="brief-field"><span>{fieldLabel('SALES MOTION', '销售路径')}</span><select value={brief.motion} onChange={(event) => updateBrief('motion', event.target.value)}>{motionOptions.map((option) => <option key={option}>{option}</option>)}</select></label>
            </div>
            <div className="context-panel-footer"><div className="context-footnote"><Sparkles size={14} /><span>{language === 'zh' ? '市场、客群、阶段、目标、ACV、预算与销售路径都会改变分析重点。' : 'Market, target, stage, objective, ACV, budget and selected motion reshape the plan.'}</span></div><button className="primary-button" onClick={handleGenerate} disabled={aiState === 'running'}>{aiState === 'running' ? <><span className="button-spinner" />{t.generating}</> : <><Sparkles size={15} />{t.generate}<ArrowRight size={15} /></>}</button></div>
            {aiState === 'error' && <div className={`error-banner error-${errorKind}`} role="alert"><span>{errorHeading}</span><small>{error}</small>{errorKind !== 'input' && <button onClick={handleGenerate}>{errorButton}</button>}</div>}
          </section>

          <div className="workflow-rail"><div className="workflow-caption"><span className="eyebrow">WORKFLOW</span><span>{planner.profile}</span></div><nav className="workflow-steps" aria-label={language === 'zh' ? 'GTM 工作流' : 'GTM workflow'}>{workflowSteps[language].map(([step, href], index) => <a className={index < 2 ? 'complete' : ''} href={href} key={`${step}-${href}`}><i>{index < 2 ? <Check size={10} /> : String(index + 1).padStart(2, '0')}</i>{step}{index < workflowSteps[language].length - 1 && <b />}</a>)}</nav></div>

          <div className="strategy-heading"><div><div className="eyebrow">02 / {t.strategyOverview.toUpperCase()}</div><h2>{strategyTitle}<span className="market-chip"><Globe2 size={12} />{brief.market}</span></h2><p>{strategyDescription}</p></div><div className={`generation-label ${aiState === 'success' ? 'ai-success' : aiState === 'error' ? 'ai-error' : ''}`}><span className="generation-dot" />{generatedLabel}</div></div>

          <div className="overview-grid"><MarketCard strategy={strategy} t={t} language={language} currency={currency} /><SegmentCard strategy={strategy} t={t} language={language} currency={currency} /><MotionCard motions={displayedMotions} modules={planner.modules} t={t} language={language} /></div>
          <div className="strategy-main-grid"><div className="strategy-left-column"><PositioningCard strategy={strategy} t={t} language={language} currency={currency} /><PricingCard strategy={strategy} t={t} language={language} currency={currency} /></div><aside className="simulator-column"><SimulatorPanel item={simulationItem} baselineItem={selectedCase} inputs={simInputs} onChange={setSimInputs} motions={displayedMotions.map((motion) => motion.name)} language={language} t={t} /></aside></div>
          <div className="secondary-grid"><CompetitorCard strategy={strategy} t={t} language={language} currency={currency} /><ChannelCard strategy={strategy} t={t} language={language} currency={currency} /></div>
          <LaunchCard strategy={strategy} t={t} language={language} currency={currency} />
          <IterationPanel key={caseId} caseId={caseId} strategy={strategy} language={language} />
          <SystemMap t={t} language={language} />
          <footer className="page-footer"><div className="footer-brand"><div className="brand-mark small"><svg viewBox="0 0 40 40" aria-hidden="true"><path d="M10 14.2 20 8.5l10 5.7v11.6L20 31.5 10 25.8V14.2Z" /><path d="M10 14.2 20 20l10-5.8M20 20v11.5" /><circle cx="10" cy="14.2" r="2.4" /><circle cx="20" cy="8.5" r="2.4" /><circle cx="30" cy="14.2" r="2.4" /><circle cx="30" cy="25.8" r="2.4" /><circle cx="20" cy="31.5" r="2.4" /><circle cx="10" cy="25.8" r="2.4" /><circle cx="20" cy="20" r="3" /></svg></div><span>GTM OS</span></div><p>{language === 'zh' ? '市场分数、竞品、定价、上市准备度及模拟结果均为示意性假设；重要决策请以客户研究与实际数据校准。' : 'Market scores, competitor notes, prices, launch readiness and simulation outputs are illustrative hypotheses. Calibrate decisions with customer research and observed data.'}</p><span className="footer-version">DECISION SYSTEM · V1.0</span></footer>
        </div>
      </main>
    </div>
  );
}

export default App;
